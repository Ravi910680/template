<?php



function cors() {

    // Allow from any origin
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
        // you want to allow, and if so:
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            // may also be using PUT, PATCH, HEAD etc
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }


}

cors();






require("../confige/templateconfige.php");





session_start();

    $mail=$_SESSION["email"];
$id=$_SESSION["id"];



$query_for_temp="SELECT * FROM temp_details WHERE id='$id'";

$tempresult = $template->query($query_for_temp);
$array_temp_det=array();
while($row = $tempresult->fetch_assoc()) {
  
	$mytemp['name'] = $row['tempname'];
$mytemp['dateofcrt'] = $row['date'];


array_push($array_temp_det,$mytemp);
}

$mytempjson = json_encode($array_temp_det);
echo $mytempjson;
    

?>
