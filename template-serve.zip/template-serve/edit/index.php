



<?php
session_start();

    $mail=$_SESSION["email"];
    $id=$_SESSION["id"];
if(isset($_SESSION["email"])){
require("../../../confige/userconnect.php");

$sql = "SELECT id FROM userinfo WHERE email='$mail' and varflag='1'";


$result=$conn->query($sql);
$count = mysqli_num_rows($result);

if($count==1)
{

if(isset($_GET['editor_id'])){


                $temp_name=$_GET['editor_id'];
		

require("../../../confige/imagedir.php");
  $select_dir="SELECT * FROM imagedirname WHERE id='$id'";
  $slected_dir = $imagedir->query($select_dir);
  $rows_count=$slected_dir->num_rows;
 
  while($row = $slected_dir->fetch_assoc()){
      $dbdata[]=$row;
  }
  $datavar=json_encode($dbdata);



?>
<script>
var t;
t=10;
</script>
<!DOCTYPE html>
<html lang="en">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css" rel="stylesheet">


<link href="https://fonts.googleapis.com/css?family=Work+Sans:200,300,400,500,600,700" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdn.scaleflex.it/plugins/filerobot-image-editor/3/filerobot-image-editor.min.js"/></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/a-color-picker@1.2.1/dist/acolorpicker.min.js"></script>
 <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:600' rel='stylesheet' type='text/css'>
<script src="../../assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>





<style>


.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    float: right;
    padding-left: 20px;
    padding-right: 20px;
}

html{
padding:0px !important;

}
body{
    font-family:'Work Sans', sans-serif;
}
.note-editor.note-frame{
    border:0px;
}
.picker {
  display: inline-block;
  box-shadow: 0 2px 2px 0 rgba(0,0,0,0.16), 0 0 0 1px rgba(3, 1, 1, 0.08);
}
.edit-on{
    outline-width:4px !important;
    outline-style: dotted !important;
  outline-color: 1px solid black !important;
}
#get-dir:focus{
    outline:none;
}
.imag-cls{
  
    border-radius:7px;
    display: block;
  width:150px;height:175px;
  
}
.content-edt-opt:focus{
    outline:none;
}
body{
    background-color:white;
}
.text56 {
  color: white;
  font-size: 20px;
  position: absolute;
  top: 50%;
  left: 50%;
  -webkit-transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
  text-align: center;
  
}
.note-editable{
    overflow:scroll;
    border:1px solid #f2f2f2;
}
.edit:hover{
    
  outline-color:black !important;
  outline-style:dotted !important;
}

.note-editable {
    line-height: 2;

}
.note-editor.note-frame .note-statusbar .note-resizebar{
    display:none;
}
.note-editor.note-frame.edit-opt-class{
    border:none;
}
.edit_opt_img_op:hover{
    cursor:pointer;
}
.drop_menu_open:hover{
    cursor:pointer;
}
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   
   color: white;
   text-align: center;
}
.ch{
    font-size:24px;
    background:white;
    margin-left:4px;

}
.soc_ico_dlt:hover{
    cursor:pointer;

}
.main-content1{
    
   
    max-height: 90%;
    position: fixed;
    overflow-y: scroll;
    background: white;
}
.tablediv{
    padding:10%;
}
.getimg{
    text-align: left;
    padding: 20px;
    color: black;
}
.slidecontainer {
  width: 100%;
}

.slider {
  -webkit-appearance: none;
  width: 100%;
  height: 15px;
  border-radius: 5px;
  background: #d3d3d3;
  outline: none;
  opacity: 0.7;
  -webkit-transition: .2s;
  transition: opacity .2s;
}

.slider:hover {
  opacity: 1;
}

.slider::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 25px;
  height: 25px;
  border-radius: 50%;
  background: #4CAF50;
  cursor: pointer;
}

.slider::-moz-range-thumb {
  width: 25px;
  height: 25px;
  border-radius: 50%;
  background: #4CAF50;
  cursor: pointer;
}
.getimg:hover {
    cursor: pointer;
    background: #f2f2f2;
    color: red;
}
.borer-type:focus{
outline:none;
}
.img_pre_ld:hover{
    background:none;
}

#dir_data{
    border:1px solid rgb(222, 221, 220);
    border-radius:0px;
    box-shadow:none;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.dropdown3 {
  position: relative;
  display: inline-block;
}

.dropdown-content3 {
  display: none;
  position: absolute;
  border: 1px solid #f2f2f2;
  background:white;
  min-width: 160px;
  
 
  z-index: 1;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 

ul{
    list-style:none;
}
.img-con {
    width:150px;height:175px;margin:20px;position: relative;
  position: relative;
  
}
.note-editor{
    border:0px;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}
.cropper-containe{
    height:100vh;
}

.content-edt-opt-active:hover{
    background:#d5e0f2;
    cursor:pointer;
    transition-duration: 0.5s;
}

.add_ele:hover{
outline:4px dotted !important;
}
.content-edt-opt-active{
    background:#becee8;
    transition-duration: 1s;
}
.content-edt-opt:hover{
    
    background:#d5e0f2;
    cursor:pointer;
    transition-duration: 0.5s;
}


.overlay:hover{
    cursor:pointer;
}
.overlay {
    
    border-radius:7px;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  height: 100%;
  width: 100%;
  opacity: 0;
  transition: .5s ease;
  background-color: #f2f2f2;
}
.dropdown-menu{
    border-radius:0px;
    box-shadow:none;
    
    border:1px solid #dedddc;
   
}
.lds-ripple {
  display: inline-block;
  position: relative;
  width: 80px;
  height: 80px;
}
.lds-ripple div {
  position: absolute;
  border: 4px solid black;
  opacity: 1;
  border-radius: 50%;
  animation: lds-ripple 1s cubic-bezier(0, 0.2, 0.8, 1) infinite;
}
.lds-ripple div:nth-child(2) {
  animation-delay: -0.5s;
}
@keyframes lds-ripple {
  0% {
    top: 36px;
    left: 36px;
    width: 0;
    height: 0;
    opacity: 1;
  }
  100% {
    top: 0px;
    left: 0px;
    width: 72px;
    height: 72px;
    opacity: 0;
  }
}

.dec_on{
    background:#becee8;
    border:1px solid #007c89;
}
.dec_off:hover{
    background:#d5e0f2;
}

#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    
    transition: color .1s cubic-bezier(.4,0,.2,1);
}

.btn_sel_ele_thr{

background: #0000ff29;
    font-weight: 600;
    border: none;
}
.btn_sel_ele_thr:hover{
cursor:pointer;
}
.sel_data_con_opt{

	display: none;
}



.midd-sel-img:hover{

cursor:pointer;


}

input:checked+label{ 


color: pink;


 } 


.midd-sel-img{
font-size: 40px;
padding: 20px;
box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
border: 1px solid black;
width: fit-content;
border-radius: 5px;
   
    margin: 20px;
}

.title_add_new_ele {
    padding-bottom: 20px;
    color: #007c89;
    font-weight: 600;

}


.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    float: right;
    padding-left: 20px;
    padding-right: 20px;
}


.bottom-btn:hover{
	cursor: pointer;
}

.opt-main-edit-con:hover{

cursor: pointer;

}
.edit:hover{

cursor: pointer;
}


.head_of_cod_edt{
height:4vh;
}
.head_of_cod_edt:hover{
cursor:pointer;
}

.sty_of_txt{

height: 4vh;
    font-weight: 500;
    font-size: 1.5vh;
    padding: 1vh;
    color: black;

}


</style>

<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css" rel="stylesheet">
   <link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet">
  
  <!-- Icons -->
  

<link href="https://fonts.googleapis.com/css2?family=Inconsolata:wght@400;500;600;700&display=swap" rel="stylesheet"> 
  <!-- CSS Files -->
  <link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css" rel="stylesheet" />
</head>
<style>
.bg-dark {
    background-color: #4a154b !important;
}
</style>

<body style="background-color:white;">
<div class="header row" id="myHeader" style='margin-left:0px;margin-right:0px;'>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark" style="height:8vh;width:50%;">
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="#" style='font-weight:700;'>heptera|<sub>editor</sub></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="../../template/" style='font-weight:600;' ><i class="fad fa-long-arrow-left" style="padding-right:10px;"></i>Back</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#" style='font-weight:700;'><i class="fad fa-chalkboard-teacher" style="
    font-size: 24px;
"></i></a>
    </li>
    
    
    
    
    
  </ul>
</nav>



<nav class="navbar navbar-expand-sm bg-dark navbar-dark" style="height:8vh;width:50%;float:right;">
  <ul class="navbar-nav">

    <li class="edit1 nav-item" style="font-weight:600;display:none">
     <a class="nav-link" href="#" id="edit1" style="
    font-size: 13px;
    text-align: center;
"><i class="fal fa-plus" aria-hidden="true"></i><br>Add</a>
    </li>
    <li class="edit1 nav-item" style="font-weight:600;display:none">
   
<a class="nav-link delet_ele" href="#" data-toggle="modal" data-target="#deleted_modal_open" style="
    font-size: 13px;
    text-align: center;
"><i class="fal fa-trash" aria-hidden="true"></i><br>Delete</a>







    </li>


<li class="edit1 nav-item" style="display: inline-block;color: white;">
<a class="nav-link " id="code_to_edit_trig" href="#" style="
    font-size: 13px;
    text-align: center;
"><i class="fad fa-code"></i><br>Code</a>
</li>

<li class="edit1 nav-item" style="font-weight: 700;display: inline-block;color: white;">
<a class="nav-link " id="red_link" href="./preview/?temp_id=<?php echo $temp_name;?>"  style="
"><i class="fal fa-phone-laptop" style="
    font-size: 24px;
    font-weight: 400;
"></i></a>
    </li>

  </ul>
</nav>

</div>





<div class="full-con" style="width:100%;">
<div class="row" style="width:100%;height:84vh;overflow-y:scroll;margin-left:0px;margin-right:0px;">
<div class="full-main" style="width:60%;height:84vh;overflow-y:scroll;background:#f2f2f2;" >
<div class="main-content" style="background:#f2f2f2;margin:0px auto;margin-bottom:20px;">



<?php
$html = file_get_contents('../crt-template/crtedtemp/'.$temp_name.'.html');
echo $html;





?>
</div><!---main-content-->

</div><!--60%-->




<div class="" style="width:40%;height:84vh;overflow-y:scroll;overflow-x:hidden;">


<div class="code_connect" style="display:none" >
<div class="head_of_cod_edt"><i class="fas fa-times-circle" id="clos_cd_edt" style="
    font-size: 2vh;
    padding: 1vh;
    color: grey;
"></i></div>
<textarea style="
    height: 76vh;
    width: 100%;
    border: none;
    background: #171313e0;
    color: white;
font-family: 'Inconsolata', monospace;padding:10px;" id="code_edit_opt">




</textarea>
 <div class="sty_of_txt head_of_cod_edt">

<span><i class="fal fa-sticky-note"></i> Don't Change Class And Id Of element</span>
</div>

</div>


<div class="container" id="main_ed_con_opt"  style='border-left:1px solid #f2f2f2;padding-right:0px;padding-left:0px;'>






<div>
<div class='edit-opt-class1' id='none' style="padding:20px;border-bottom:1px solid #f2f2f2;">
<div class='width:100%;'>
<div class='row' style='margin-right:0px;margin-left:0px;border:1px solid;border-radius:2px;'>

<button class="content-edt-opt style-edt-opt" id='style2' style='width:50%;padding:20px;height:fit-content;padding:10px;border:none;border-right:1px solid;' >
style
</button>
<button class="content-edt-opt back-edt-opt" id='back-setting' style='width:50%;padding:20px;height:fit-content;padding:10px;border:none;' >
back setting
</button>
</div>
</div>
</div>

</div>
<div style="width:100%;border-bottom:1px solid #dedddc;color:#007c89">
<div class='row' style='margin-left:0px;margin-right:0px;padding:10px;'>
<div class='opt-main-edit-con' style='width:50%' id='back_con_show'>Add content</div>
<div class='opt-main-edit-con' style='width:50%;text-align:center;'>learn more about editor</div>
</div>
</div>
<div class="edit-content" style="background:white;">


<div id="img-loader2" style="height:100%;padding:50%;display:none;">
<div class="lds-ripple"><div></div><div></div></div>
</div>

<div id='con_for_add' class='' style="width:100%;padding:20px;" >
<div class='title_add_new_ele'>Element Content<span class="span_for_ele" style="
    border-top: 1px solid;
    display: block;
    width: 100%;
"></span></div>
<div class='row' style='margin-left:0px;margin-right:0px;'>

<div class='' draggable="true" ondragstart="drag(event)" id='drag_on1' ondragend="dragEnd(event)"  style='width:20%;background:#fafaf7;margin: 0px auto;border:1px solid;border-radius:5px;margin-bottom:15px;'>
<div class='' style='text-align:center'>



<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 224 180"><defs><style>.a{fill:#c7c7c7;}</style></defs><title>text</title><rect class="a" x="48" y="46" width="128" height="4"/><rect class="a" x="48" y="56" width="128" height="4"/><rect class="a" x="48" y="66" width="128" height="4"/><rect class="a" x="48" y="76" width="128" height="4"/><rect class="a" x="48" y="86" width="128" height="4"/><rect class="a" x="48" y="96" width="128" height="4"/><rect class="a" x="48" y="106" width="128" height="4"/><rect class="a" x="48" y="116" width="128" height="4"/><rect class="a" x="48" y="126" width="128" height="4"/><rect class="a" x="48" y="136" width="88" height="4"/></svg>
</div>
</div>


<div class='' draggable="true" ondragstart="drag(event)" id='drag_on2' ondragend="dragEnd(event)"  style='width:20%;background:#fafaf7;border:1px solid;border-radius:5px;margin:0px auto;margin-bottom:15px;'>
<div class='' style='text-align:center'>


<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 224 180"><defs><style>.a{fill:#b7b7b7;}.b{fill:#c7c7c7;}</style></defs><title>boxedText</title><path class="a" d="M182,41.5v106H42V41.5H182m4-4H38v114H186V37.5Z"/><rect class="b" x="48" y="47.5" width="128" height="4"/><rect class="b" x="48" y="57.5" width="128" height="4"/><rect class="b" x="48" y="67.5" width="128" height="4"/><rect class="b" x="48" y="77.5" width="128" height="4"/><rect class="b" x="48" y="87.5" width="128" height="4"/><rect class="b" x="48" y="97.5" width="128" height="4"/><rect class="b" x="48" y="107.5" width="128" height="4"/><rect class="b" x="48" y="117.5" width="128" height="4"/><rect class="b" x="48" y="127.5" width="128" height="4"/><rect class="b" x="48" y="137.5" width="88" height="4"/></svg>
</div>
</div>



<div class='' draggable="true" ondragstart="drag(event)" id='drag_on3' ondragend="dragEnd(event)"  style='width:20%;background:#fafaf7;border:1px solid;border-radius:5px;margin:0px auto;margin-bottom:15px;'>
<div class='' style='text-align:center'>

<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 224 180"><defs><style>.a{fill:#e0e0e0;}.b{fill:#b7b7b7;}</style></defs><title>divider</title><rect class="a" x="48.2" y="37.5" width="128" height="44"/><rect class="b" x="38.2" y="92.5" width="148" height="4"/><rect class="a" x="48.2" y="107.5" width="128" height="44"/></svg>
</div>
</div>
















<div class='' draggable="true" ondragstart="drag(event)" id='drag_on1' ondragend="dragEnd(event)"  style='width:20%;margin: 0px auto;background:#fafaf7;border:1px solid;border-radius:5px;margin-bottom:15px;'>
<div class='' style='text-align:center'>


<svg viewBox="0 0 224 180" xmlns="http://www.w3.org/2000/svg"><defs><style>.a{fill:#e0e0e0;}.b{fill:#b7b7b7;}</style></defs><path class="a" d="M48 48h128v94H48z"/><path class="b" d="M182 42v106H42V42h140m4-4H38v114h148V38z"/><path class="b" d="M48 112.1V142h128v-30l-20-20-22 20-44-41-42 41.1"/><g id="blimpIcon"><g id="Layer_1"><g id="Group"><g id="blimpIcon"><g id="Layer_1"><g id="Group" stroke="#B5B5B5" fill="#B5B5B5"><path d="M148.93 69.854c.428.71.428 1.628 0 2.338-2.733 4.615-10.053 5.237-15.208 5.118-5.383-.118-10.026-1.36-11.678-1.952-2.42-.888-4.984-2.338-6.864-4.172-.17-.148-.17-.385 0-.533 1.88-1.834 4.415-3.106 6.864-3.964 1.652-.593 6.295-1.836 11.678-1.954 5.155-.118 12.475.503 15.21 5.118z" id="Shape" stroke-width=".86"/><path d="M132.09 76.397c-1.014-.04-1.99-.083-2.93-.165v3.6h7.2v-3.518c-1.485.124-2.932.124-4.27.083z" id="Shape" stroke-width=".86"/><path d="M118.79 73.8l.32 3.6 2.096-.062c1.282-.042 2.44-.708 2.983-1.686M118.79 68.4l.32-3.6 2.096.062c1.282.042 2.44.708 2.983 1.686" id="Shape" stroke-width=".688"/></g></g></g></g></g></g></svg>
</div>
</div>




</div>

<div class='row' style='margin-left:0px;margin-right:0px;'>




<div class='' draggable="true" ondragstart="drag(event)" id='drag_on4' ondragend="dragEnd(event)"  style='width:20%;background:#fafaf7;border:1px solid;border-radius:5px;margin:0px auto;margin-bottom:15px;'>
<div class='' style='text-align:center'>


<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 224 181"><defs><style>.a{fill:#e2e2e2;}.b{fill:#c7c7c7;}.c{fill:#b7b7b7;}</style></defs><title>imageCard</title><path class="a" d="M48 32h128v82H48z"/><path class="b" d="M48 120h128v4H48zM48 130h128v4H48zM48 140h88v4H48z"/><path class="c" d="M182 26v124H42V26h140m4-4H38v132h148V22z"/><path class="c" d="M48 96.1V114h128V96l-20-20-22 20-44-41-42 41.1"/><g id="blimpIcon"><g id="Layer_1"><g id="Group"><g id="blimpIcon"><g id="Layer_1"><g id="Group" stroke="#B5B5B5" fill="#B5B5B5"><path d="M149.93 50.854c.428.71.428 1.628 0 2.338-2.733 4.615-10.053 5.237-15.208 5.118-5.383-.118-10.026-1.36-11.678-1.952-2.42-.888-4.984-2.338-6.864-4.172-.17-.148-.17-.385 0-.533 1.88-1.834 4.415-3.106 6.864-3.964 1.652-.593 6.295-1.836 11.678-1.954 5.155-.118 12.475.503 15.21 5.118z" id="Shape" stroke-width=".86"/><path d="M133.09 57.397c-1.014-.04-1.99-.083-2.93-.165v3.6h7.2v-3.518c-1.485.124-2.932.124-4.27.083z" id="Shape" stroke-width=".86"/><path d="M119.79 54.8l.32 3.6 2.096-.062c1.282-.042 2.44-.708 2.983-1.686M119.79 49.4l.32-3.6 2.096.062c1.282.042 2.44.708 2.983 1.686" id="Shape" stroke-width=".688"/></g></g></g></g></g></g></svg>
</div>
</div>







<div class='' draggable="true" ondragstart="drag(event)" id='drag_on7' ondragend="dragEnd(event)" style='margin: 0px auto;width:20%;background:#fafaf7;border:1px solid;border-radius:5px;margin-bottom:15px;'>
<div class='' style='text-align:center'>


<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 224 180"><defs><style>.a{fill:#b6b6ba;}</style></defs><title>socialShare</title><path class="a" d="M97.9,52a20.9,20.9,0,0,1,.1,2.5,26,26,0,1,1-26.5-26,41.17,41.17,0,0,1,6.6-3.4,30,30,0,1,0,23.3,35.5,30.69,30.69,0,0,0,.1-11.7Z"/><path class="a" d="M152,24.5a30,30,0,1,0,30,30A30,30,0,0,0,152,24.5Zm8,20h-3c-2.2,0-3,1.1-3,2.6v3.4h6l-1,5h-5v14h-5v-14h-5v-5h5v-4c0-4.6,2.6-7,6.7-7,1.4,0,2.9.1,4.3.2Z"/><path class="a" d="M152,102.5a30,30,0,1,0,30,30,30,30,0,0,0-30-30Zm15,32v10h-6.2v-10a3.64,3.64,0,0,0-3.3-3.8h-.4c-2.5,0-3.8,1.3-3.8,2.5v11.3H147v-19h6.2v2.8c.1-.4,1.7-2.5,6.2-2.5C163.6,125.7,167,128.7,167,134.5Zm-30-9h6.2v19H137Zm6.2-5.4a2.89,2.89,0,0,1-2.9,3.1H140a3.1,3.1,0,1,1,0-6.2A3.08,3.08,0,0,1,143.2,120.1Z"/><path class="a" d="M72,102.5a30,30,0,1,0,30,30,30,30,0,0,0-30-30ZM85.6,123a7,7,0,0,0,3.2-.6,6.63,6.63,0,0,1-3.2,3.2c0,.3-.1.9-.1,1.2,0,9.2-6.4,19.7-19.4,19.7a20.44,20.44,0,0,1-11-3.2c3.9,0,7.1-.6,10.3-3.2-3.9.6-6.5-2.5-7.1-5.1a4.45,4.45,0,0,0,3.9,0c-6.5-.6-5.8-6.3-5.8-6.3a4,4,0,0,0,2.6.6c-1.9-1.2-3.9-5.1-1.9-9.5A21.11,21.11,0,0,0,72,127.4c-.7-1.9-.7-8.3,5.8-8.9,3.9-.4,5.2,1.3,5.8,2.6a14.87,14.87,0,0,0,4.5-1.9A5.05,5.05,0,0,1,85.6,123Z"/><path class="a" d="M60,61.5c2.4-4.1,5-17.5,28-19v10l20-17-20-17V28.7c-6.2.8-25,5.4-30,32.8Z"/></svg>
</div>
</div>
















<div class='' draggable="true" ondragstart="drag(event)" id='drag_on8' ondragend="dragEnd(event)" style='margin: 0px auto;width:20%;background:#fafaf7;border:1px solid;border-radius:5px;margin-bottom:15px;'>
<div class='' style='text-align:center'>


<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 224 180"><defs><style>.a{fill:#e0e0e0;}.b{fill:#939394;}</style></defs><title>button</title><path class="a" d="M44,66.5H180a8,8,0,0,1,8,8v38a8,8,0,0,1-8,8H44a8,8,0,0,1-8-8v-38A8,8,0,0,1,44,66.5Z"/><path class="b" d="M123.9,125.7l10.1.8-22-26v34.4l6.7-7.5,5.1,13.4a2.71,2.71,0,0,0,2.6,1.7c.3,0,.6-.1.9-.1a2.46,2.46,0,0,0,1.8-2.4,2.92,2.92,0,0,0-.2-.9Z"/></svg>
</div>
</div>

<div class='' draggable="true" ondragstart="drag(event)" id='drag_on9' ondragend="dragEnd(event)" style='width:20%;background:#fafaf7;border:1px solid;margin:0px auto;border-radius:5px;margin-bottom:15px;'>
<div class='' style='text-align:center'>

<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 224 180" ><defs><style>.a{fill:#c7c7c7}</style></defs><title>text</title><rect class="a" x="68" y="46" width="34" height="4"/><rect class="a" x="122" y="46" width="54" height="4"/><rect class="a" x="48" y="56" width="54" height="4"/><rect class="a" x="122" y="56" width="54" height="4"/><rect class="a" x="48" y="66" width="54" height="4"/><rect class="a" x="122" y="66" width="54" height="4"/><rect class="a" x="48" y="76" width="54" height="4"/><rect class="a" x="122" y="76" width="54" height="4"/> <rect class="a" x="48" y="86" width="54" height="4"/><rect class="a" x="122" y="86" width="54" height="4"/> <rect class="a" x="48" y="96" width="54" height="4"/><rect class="a" x="122" y="96" width="54" height="4"/> <rect class="a" x="48" y="106" width="54" height="4"/><rect class="a" x="122" y="106" width="54" height="4"/> <rect class="a" x="48" y="116" width="54" height="4"/><rect class="a" x="122" y="116" width="54" height="4"/> <rect class="a" x="48" y="126" width="54" height="4"/><rect class="a" x="122" y="126" width="54" height="4"/><rect class="a" x="48" y="136" width="54" height="4"/><rect class="a" x="122" y="136" width="54" height="4"/></svg>


</div>
</div>






</div>



<div class='title_add_new_ele'>New Element<span class="span_for_ele" style="
    border-top: 1px solid;
    display: block;
    width: 100%;
"></span></div>
<div class='row' style='margin-left:0px;margin-right:0px;'>
<div class='' draggable="true" ondragstart="drag(event)" id='drag_on11' ondragend="dragEnd(event)" style='width:20%;background:#fafaf7;border:1px solid;margin:0px auto;border-radius:5px;margin-bottom:15px;'>
<div class='' style='text-align:center'>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 224 180" ><defs><style>.a{fill:#c7c7c7}</style></defs><title>text</title>

 <rect class="a" x="48" y="50" rx='4' ry='4' width="33.333" height="100"/>
 <rect class="a" x="95.3333" y="50" rx='4' ry='4' width="33.333" height="100"/>
 <rect class="a" x="142.6666" y="50" rx='4' ry='4' width="33.333" height="100"/>

 </svg>

</div>
</div>





<div class='' draggable="true" ondragstart="drag(event)" id='drag_on14' ondragend="dragEnd(event)" style='width:20%;background:#fafaf7;border:1px solid;margin:0px auto;border-radius:5px;margin-bottom:15px;'>
<div class='' style='text-align:center'>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 224 180" ><defs><style>.a{fill:#c7c7c7}</style></defs><title>text</title>

 <rect class="a" x="48" y="50" rx='4' ry='4' width="33.333" height="45"/>
 <rect class="a" x="95.3333" y="50" rx='4' ry='4' width="33.333" height="45"/>
 <rect class="a" x="142.6666" y="50" rx='4' ry='4' width="33.333" height="45"/>
 <rect class="a" x="48" y="105" rx='4' ry='4' width="33.333" height="45"/>
<rect class="a" x="95.3333" y="105" rx='4' ry='4' width="33.333" height="45"/>
<rect class="a" x="142.6666" y="105" rx='4' ry='4' width="33.333" height="45"/>

 </svg>

</div>
</div>

<div class='' draggable="true" ondragstart="drag(event)" id='drag_on13' ondragend="dragEnd(event)" style='width:20%;background:#fafaf7;border:1px solid;margin:0px auto;border-radius:5px;margin-bottom:15px;'>
<div class='' style='text-align:center'>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 224 180" ><defs><style>.a{fill:#c7c7c7}</style></defs><title>text</title>

 <rect class="a" x="48" y="56" rx='4' ry='4' width="54" height="100"/>

 <rect class="a" x="122" y="56" rx='4' ry='4' width="54" height="100"/>

 </svg>

</div>
</div>

<div class='' draggable="true" ondragstart="drag(event)" id='drag_on15' ondragend="dragEnd(event)" style='width:20%;background:#fafaf7;border:1px solid;margin:0px auto;border-radius:5px;margin-bottom:15px;'>
<div class='' style='text-align:center'>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 224 180" ><defs><style>.a{fill:#c7c7c7}</style></defs><title>text</title>

 <rect class="a" x="48" y="56" rx='4' ry='4' width="54" height="45"/>
 
 <rect class="a" x="48" y="111" rx='4' ry='4' width="54" height="45"/>

 <rect class="a" x="122" y="56" rx='4' ry='4' width="54" height="45"/>
<rect class="a" x="122" y="111" rx='4' ry='4' width="54" height="45"/>
 </svg>

</div>
</div>

</div>
</div>





<div class="add_drg_ele" style='display:none;' >

<div id='drag_on12'>

<table>
<tbody>

<tr  >
<td style='padding-top:0px;padding-bottom:0px;' class='edit text' style='max-width:100%;padding:20px;' id='546' width='50%'>
<p style='padding:20px;'>
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of</p>
</td>

</tr>
</tbody>
</table>

</div>

<div id='drag_on22'>

<table>
<tbody>

<tr >
<td class='edit text'  style='max-width:100%;padding:20px;margin:20px;background:#e6e8ee;' id='546' width='50%'>


<p>
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since </p>

</td>

</tr>
</tbody>
</table>

</div>
<div id='drag_on112'>


<table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                            <tbody><tr>
				<td valign="top" style="padding: 0;" class="mobile-wrapper">


 <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="33%" align="left" class="responsive-table">
                                        <tbody><tr>
                                            <td style="padding: 20px;">
                                                <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                                                    <tbody><tr>
                                                        <td align="center" bgcolor="#ffffff" valign="middle" class="add_dy_ele">



<div class="chg_con_of_md" data-toggle="modal" data-target="#select_ele_ele"><button class="btn_sel_ele_thr"><i class="fad fa-layer-plus" aria-hidden="true"></i> Select Content</button></div>
</td>
                                                    </tr>

                                                </tbody></table>
                                            </td>
                                        </tr>
                                    </tbody></table>

                                    <!-- LEFT COLUMN -->
                                    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="33%" align="left" class="responsive-table">
                                        <tbody><tr>
                                            <td style="padding: 20px;">
                                                <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                                                    <tbody><tr>
                                                        <td align="center" bgcolor="#ffffff" valign="middle" class="add_dy_ele">



<div class="chg_con_of_md" data-toggle="modal" data-target="#select_ele_ele"><button class="btn_sel_ele_thr"><i class="fad fa-layer-plus" aria-hidden="true"></i> Select Content</button></div>
</td>
                                                    </tr>
               
                                                </tbody></table>
                                            </td>
                                        </tr>
                                    </tbody></table>
                                    <!-- RIGHT COLUMN -->
                                    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="33%" align="right" class="responsive-table">
                                        <tbody><tr>
                                            <td style="padding: 20px;">
                                                <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                                                    <tbody><tr>
                                                        <td align="center" bgcolor="#ffffff" valign="middle" class="add_dy_ele">
    
<div class="chg_con_of_md" data-toggle="modal" data-target="#select_ele_ele"><button class="btn_sel_ele_thr"><i class="fad fa-layer-plus" aria-hidden="true"></i> Select Content</button></div>

</td>                                                    </tr>
                                                  
                                                    
                                                </tbody></table>
                                            </td>
                                        </tr>
                                    </tbody></table>
                                </td>
                            </tr>
                   </table>
</div>


<div id='drag_on142'>


<table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                            <tbody><tr>
                                <td valign="top" style="padding: 0;" class="mobile-wrapper">
                                    <!-- LEFT COLUMN -->
                                    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="31%" align="left" class="responsive-table">
                                        <tbody><tr>
                                            <td style="padding: 20px;">
                                                <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                                                    <tbody><tr>
                                                        <td align="center" bgcolor="#ffffff" valign="middle" class="add_dy_ele">



<div class="chg_con_of_md" data-toggle="modal" data-target="#select_ele_ele"><button class="btn_sel_ele_thr"><i class="fad fa-layer-plus" aria-hidden="true"></i> Select Content</button></div>
</td>
                                                    </tr>


                                                    <tr>
                                                        <td align="center" bgcolor="#ffffff" valign="middle" class="add_dy_ele">



<div class="chg_con_of_md" data-toggle="modal" data-target="#select_ele_ele"><button class="btn_sel_ele_thr"><i class="fad fa-layer-plus" aria-hidden="true"></i> Select Content</button></div>
</td>
                                                    </tr>

                                                </tbody></table>
                                            </td>
                                        </tr>
                                    </tbody></table>

                                     <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="31%" align="left" class="responsive-table">
                                        <tbody><tr>
                                            <td style="padding: 20px;">
                                                <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                                                    <tbody><tr>
                                                        <td align="center" bgcolor="#ffffff" valign="middle" class="add_dy_ele">



<div class="chg_con_of_md" data-toggle="modal" data-target="#select_ele_ele"><button class="btn_sel_ele_thr"><i class="fad fa-layer-plus" aria-hidden="true"></i> Select Content</button></div>
</td>
                                                    </tr>

                                                    <tr>
                                                        <td align="center" bgcolor="#ffffff" valign="middle" class="add_dy_ele">



<div class="chg_con_of_md" data-toggle="modal" data-target="#select_ele_ele"><button class="btn_sel_ele_thr"><i class="fad fa-layer-plus" aria-hidden="true"></i> Select Content</button></div>
</td>
                                                    </tr>

                                                </tbody></table>
                                            </td>
                                        </tr>
                                    </tbody></table>
                                    <!-- RIGHT COLUMN -->
                                     <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="31%" align="left" class="responsive-table">
                                        <tbody><tr>
                                            <td style="padding: 20px;">
                                                <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                                                    <tbody><tr>
                                                        <td align="center" bgcolor="#ffffff" valign="middle" class="add_dy_ele">



<div class="chg_con_of_md" data-toggle="modal" data-target="#select_ele_ele"><button class="btn_sel_ele_thr"><i class="fad fa-layer-plus" aria-hidden="true"></i> Select Content</button></div>
</td>
                                                    </tr>

                                                    <tr>
                                                        <td align="center" bgcolor="#ffffff" valign="middle" class="add_dy_ele">



<div class="chg_con_of_md" data-toggle="modal" data-target="#select_ele_ele"><button class="btn_sel_ele_thr"><i class="fad fa-layer-plus" aria-hidden="true"></i> Select Content</button></div>
</td>
                                                    </tr>

                                                </tbody></table>
                                            </td>
                                        </tr>
                                    </tbody></table>
                                </td>
                            </tr>
                        </tbody></table>


</div>















<div id='drag_on152'>

<table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                            <tbody><tr>
                                <td valign="top" style="padding: 0;" class="mobile-wrapper">
                                    <!-- LEFT COLUMN -->
                                    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="47%" align="left" class="responsive-table">
                                        <tbody><tr>
                                            <td style="padding: 20px;">


                                                <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                                                    <tbody><tr>
                                                        <td align="center" bgcolor="#ffffff" valign="middle" class="add_dy_ele">



<div class="chg_con_of_md" data-toggle="modal" data-target="#select_ele_ele"><button class="btn_sel_ele_thr"><i class="fad fa-layer-plus" aria-hidden="true"></i> Select Content</button></div>
</td>
                                                    </tr>

                                                    <tr>
                                                        <td align="center" bgcolor="#ffffff" valign="middle" class="add_dy_ele">



<div class="chg_con_of_md" data-toggle="modal" data-target="#select_ele_ele"><button class="btn_sel_ele_thr"><i class="fad fa-layer-plus" aria-hidden="true"></i> Select Content</button></div>
</td>
                                                    </tr>
               
                                                </tbody></table>
                                            </td>
                                        </tr>


                                    </tbody></table>
                                    <!-- RIGHT COLUMN -->





                                    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="47%" align="right" class="responsive-table">
                                        <tbody><tr>
                                            <td style="padding: 20px;">
                                                <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                                                    <tbody><tr>
                                                        <td align="center" bgcolor="#ffffff" valign="middle" class="add_dy_ele">
    
<div class="chg_con_of_md" data-toggle="modal" data-target="#select_ele_ele"><button class="btn_sel_ele_thr"><i class="fad fa-layer-plus" aria-hidden="true"></i> Select Content</button></div>

</td>                                                    </tr>

<tr>
                                                        <td align="center" bgcolor="#ffffff" valign="middle" class="add_dy_ele">
    
<div class="chg_con_of_md" data-toggle="modal" data-target="#select_ele_ele"><button class="btn_sel_ele_thr"><i class="fad fa-layer-plus" aria-hidden="true"></i> Select Content</button></div>

</td>                                                    </tr>
                                                  
                                                    
                                                </tbody></table>
                                            </td>
                                        </tr>
                                    </tbody></table>
                                </td>
                            </tr>
                        </tbody></table>


</div>






































<div id='drag_on132'>
<table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                            <tbody><tr>
                                <td valign="top" style="padding: 0;" class="mobile-wrapper">
                                    <!-- LEFT COLUMN -->
                                    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="47%" align="left" class="responsive-table">
                                        <tbody><tr>
                                            <td style="padding: 20px;">
                                                <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                                                    <tbody><tr>
                                                        <td align="center" bgcolor="#ffffff" valign="middle" class="add_dy_ele">



<div class="chg_con_of_md" data-toggle="modal" data-target="#select_ele_ele"><button class="btn_sel_ele_thr"><i class="fad fa-layer-plus" aria-hidden="true"></i> Select Content</button></div>
</td>
                                                    </tr>
               
                                                </tbody></table>
                                            </td>
                                        </tr>
                                    </tbody></table>
                                    <!-- RIGHT COLUMN -->
                                    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="47%" align="right" class="responsive-table">
                                        <tbody><tr>
                                            <td style="padding: 20px;">
                                                <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                                                    <tbody><tr>
                                                        <td align="center" bgcolor="#ffffff" valign="middle" class="add_dy_ele">
    
<div class="chg_con_of_md" data-toggle="modal" data-target="#select_ele_ele"><button class="btn_sel_ele_thr"><i class="fad fa-layer-plus" aria-hidden="true"></i> Select Content</button></div>

</td>                                                    </tr>
                                                  
                                                    
                                                </tbody></table>
                                            </td>
                                        </tr>
                                    </tbody></table>
                                </td>
                            </tr>
                        </tbody></table>
</div>

<div id='drag_on82'>

<table width='100%'>
<tr>
<td align="center" style='padding:10px;'>
<a style='padding:10px;background:blue;color:white;border-radius:20px;' href="#" class='edit hrtag'>heptera.me</a>
</td>
</tr>
</table>

</div>


<div id='drag_on102'>
<table style="width:100%">
<tbody>

<tr>
<td width="100%">
  <div class="row">
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12" style="text-align:center;">
<img class="edit img" src="http://heptera.me/dash/main/template/img-log/300*200.png" width="250" id="53">

<div class="edit text" style="padding:20px;text-align:left;" id="54">
<h3>Keanu Reeves Rarly Talks Abount Money- But When He Does It's Life changing.</h3>
   <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries,</p>
</div>
</div>

<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12" style="text-align:center;">
<img class="edit img" src="http://heptera.me/dash/main/template/img-log/300*200.png" width="250" id="55">

<div class="edit text" style="padding:20px;text-align:left;" id="56">
<h3>Keanu Reeves Rarly Talks Abount Money- But When He Does It's Life changing.</h3>
   <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries,</p>
</div>
</div>


</div>
</td>

</tr>
</tbody>
</table>
</div>

<div id='drag_on32'>

<table style='width:100%'>
<tbody>

<tr >
<td  style='padding-top:0px;padding-bottom:0px;max-width:100%;padding:20px;border-top:5px solid #f2f2f2;' id='546'>

</td>

</tr>
</tbody>
</table>

</div>





<div id='drag_on92'>

<table style='width:100%'>
<tbody>

<tr >
<td  style='padding-top:0px;padding-bottom:0px;max-width:100%;padding:20px;' id='546'>
<div class='row'>
<div class='edit text col-lg-6 col-md-6 col-sm-12 col-xs-12'>
<p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lo</p>
</div>
<div class='edit text col-lg-6 col-md-6 col-sm-12 col-xs-12'>
<p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lo</p>
</div>
</div>
</td>

</tr>
</tbody>
</table>

</div>





<div id='drag_on42'>

<table border="0" cellpadding="0" cellspacing="0" width="600" class="flexibleContainer">
                                                	<tbody><tr>
                                                    	<td align="center" valign="top" width="600" class="flexibleContainerCell bottomShim">
                                                        	<table border="0" cellpadding="0" cellspacing="0" width="100%" class="nestedContainer">
                                                            	<tbody><tr>
                                                                	<td align="center" valign="top" class="nestedContainerCell">


                                                                        <!-- CONTENT TABLE // -->
                                                                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                                                            <tbody><tr>
                                                                                <td valign="top" class="imageContent">
                                                                                    <img src="https://heptera.me/dash/main/template/img-log/300*200.png" width="520" class="edit img flexibleImage" style="max-width:520px;">
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td valign="top" class="edit text textContent">
                                                                                    <h3>Title</h3>
                                                                                    <br>
                                                                                    A kitten or kitty is a juvenile domesticated cat. A feline litter usually consists of two to five kittens. To survive, kittens need the care of their mother for the first several weeks of their life. Kittens are highly social animals and spend most of their waking hours playing and interacting with available companions.
                                                                                </td>
                                                                            </tr>
                                                                        </tbody></table>
                                                                        <!-- // CONTENT TABLE -->


                                                                    </td>
                                                                </tr>
                                                            </tbody></table>
                                                        </td>
                                                    </tr>
                                                </tbody></table>


</div>


<div id='drag_on72'>
<table cellspacing="0" cellpadding="0" border="0" align="right" width='100%'>
                    <tbody><tr>
                       <td  class='edit btnon' id='3' style="padding:16px;" valign="top" ><table cellspacing="0" cellpadding="0" border="0" align="right">
                    <tbody><tr>
                      <td valign="top" align="center"><a href="#" target="_blank" class="soc_ico" id="facebook" style="text-decoration:none;"><img src="http://heptera.me/dash/main/template/iconfolder/facebook-flat.png" alt="fb" style="display:block; font-family:Arial, sans-serif; font-size:14px; line-height:14px; color:#ffffff; max-width:48px;" width="48" border="0" height="48"></a></td>
                      <td style="width:6px;" width="6">&nbsp;</td>
                      <td valign="top" align="center"><a href="#" target="_blank" class="soc_ico" id="instagram" style="text-decoration:none;"><img src="http://heptera.me/dash/main/template/iconfolder/instagram-flat.png" alt="tw" style="display:block; font-family:Arial, sans-serif; font-size:14px; line-height:14px; color:#ffffff; max-width:48px;" width="48" border="0" height="48"></a></td>
                      <td style="width:6px;" width="6">&nbsp;</td>
                      <td valign="top" align="center"><a href="#" target="_blank" class="soc_ico" id="tumblr" style="text-decoration:none;"><img src="http://heptera.me/dash/main/template/iconfolder/tumblr-flat.png" alt="yt" style="display:block; font-family:Arial, sans-serif; font-size:14px; line-height:14px; color:#ffffff; max-width:48px;" width="48" border="0" height="48"></a></td>
                    </tr>
                  </tbody></table></td>
                    </tr>
                  </tbody></table>

</div>


<div id='drag_on62'>

<table width='100%' style='width:100%'>
<tbody>

<tr width='100%'>
<td  class=''>
<div class='row' style='margin-left:0px;margin-right:0px;'>

<img class='edit img img_width' src='http://heptera.me/dash/main/template/img-log/300*200.png' width='100%'  height='300px;' style='padding:20px;' />


<div class='edit text img_width'  style='padding:20px;' valign='center' >
<p>
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since </p>
</div>
</div>
</td>


</tr>
</tbody>
</table>

</div>



<div id='drag_on52'>

<table border="0" cellpadding="0" cellspacing="0" style='width:100%'>
<tbody>

<tr >
<td width='100%' align='center' >
<div class='row' style='margin-left:0px;margin-right:0px;'>
<img class='edit img img_width' src='http://heptera.me/dash/main/template/img-log/300*200.png'  height='300px;' style='padding:20px;' />

<img class='edit img img_width' src='http://heptera.me/dash/main/template/img-log/300*200.png'  height='300px;' style='padding:20px;' />
</div>
</td>



</td>

</tr>
</tbody>
</table>

</div>

</div>




<script>



</script>

<div class="style-res-img" style="display:none;">
<div style="color:black;font-weight:600;font-size:20px;padding:10px">
Border setting
</div>
<div class="row" style="padding:25px;margin-left:0px;margin-right:0px;">
<div style="width:50%">
<div class="dropdown" style="width:100%;padding-right:10px;">

<button class="borer-type" style="height:40px;background:#f2f2f2;width:100%;background:none;" data-toggle="dropdown">border type <span><i class="fas fa-chevron-down"></i></span></button>
  
  <div class="dropdown-menu" style="border-radius:0px;box-shadow:none;border:1px solid #f2f2f2;width:100%">
    <a class="dropdown-item border-dec" id="none"    href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">none</div><div style="margin-top:10px;width:70%;" ></div></div></a>
    <a class="dropdown-item border-dec" id="dotted"    href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">dotted</div><div style="margin-top:10px;border-top:4px solid;border-style:dotted;width:70%;" ></div></div></a>
    <a class="dropdown-item border-dec" id="dashed"    href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">dashed</div><div style="margin-top:10px;border:none;border-top:4px;border-style:dashed;width:70%;" ></div></div></a>
    <a class="dropdown-item border-dec" id="solid"   href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">solid</div><div style="margin-top:10px;border-top:4px solid;border-style:solid;width:70%;" ></div></div></a>
    <a class="dropdown-item border-dec" id="double"    href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">double</div><div style="margin-top:10px;border-top:4px solid;border-style:double;width:70%;" ></div></div></a>
    <a class="dropdown-item border-dec" id="groove"    href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">groove</div><div style="margin-top:10px;border-top:4px solid;border-style:groove;width:70%;" ></div></div></a>
    <a class="dropdown-item border-dec" id="ridge"    href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">ridge</div><div style="margin-top:10px;border-top:4px solid;border-style:double;width:70%;" ></div></div></a>
    <a class="dropdown-item border-dec" id="inset"    href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">inset</div><div style="margin-top:10px;border-top:4px solid;border-style:inset;width:70%;" ></div></div></a>
    <a class="dropdown-item border-dec" id="outset"    href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">outset</div><div style="margin-top:10px;border-top:4px solid;border-style:double;width:70%;" ></div></div></a>
   
    
  </div>
</div><!-drop-->
</div><!--50%-->







<input type='number' id="border_weight_def" value="1" style="text-align:center;width:40px;"/><span style="padding:10px;color:black">px</span>
</div><!---row-->
<div class="" style="width:100%;padding-left:25px;padding-right:25px;padding-top:10px;">
<div class="dropdown3 border-change" >
<div style="padding:10px;border-radius:5px;border:2px solid #f2f2f2;">
  <span><div class="border-init-clr" style="width:40px;height:10px;"></div></span>
</div>
  <div class="dropdown-content3 border-img-clr" style="width:100%;" >
 <div class="border-img-sel-clr" acp-color="#EFE9E7" acp-show-rgb="no" acp-show-hsl="no">
</div>
 
  </div>
</div>
</div>


<div style="color:black;font-weight:600;font-size:20px;padding:10px">
Image align
</div>

<div style="text-align:left;padding:20px;">
<div style="padding:10px;border:1px solid #bdbbb9;color:black;border-radius:2px 0px 0px 2px;display:inline-block;border-right:0px;width:40px;text-align:center" class="img_dec_clc dec_off" id="justify"><i class="fas fa-align-justify"></i></div><div style="display:inline-block;padding:10px;border:1px solid #bdbbb9;color:black;border-radius:0px 2px 2px 0px;width:40px;text-align:center" class="img_dec_clc dec_off" id="center"><i class="fas fa-align-center"></i></div>


<div style="padding:10px;border:1px solid #bdbbb9;color:black;border-radius:2px 0px 0px 2px;display:inline-block;border-right:0px;width:40px;text-align:center" class="img_dec_clc dec_off" id="right"><i class="fas fa-align-right"></i></div><div style="display:inline-block;padding:10px;border:1px solid #bdbbb9;color:black;border-radius:0px 2px 2px 0px;width:40px;text-align:center" class="img_dec_clc dec_off" id="left"><i class="fas fa-align-left"></i></div>

</div>



<div style="color:black;font-weight:600;font-size:20px;padding:10px">
outline setting
</div>
<div class="row" style="padding:25px;">
<div style="width:50%">
<div class="dropdown" style="width:100%;padding-left:10px;padding-right:10px;">

<button class="borer-type" style="height:40px;background:#f2f2f2;width:100%;background:none;" data-toggle="dropdown">outline type <span><i class="fas fa-chevron-down"></i></span></button>
  
  <div class="dropdown-menu" style="border-radius:0px;box-shadow:none;border:1px solid #f2f2f2;width:100%">
    <a class="dropdown-item outline-dec" id="none"   href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">none</div><div style="margin-top:10px;width:70%;" ></div></div></a>
    <a class="dropdown-item outline-dec" id="dotted"   href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">dotted</div><div style="margin-top:10px;border-top:4px solid;border-style:dotted;width:70%;" ></div></div></a>
    <a class="dropdown-item outline-dec" id="dashed"   href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">dashed</div><div style="margin-top:10px;border:none;border-top:4px;border-style:dashed;width:70%;" ></div></div></a>
    <a class="dropdown-item outline-dec" id="solid"    href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">solid</div><div style="margin-top:10px;border-top:4px solid;border-style:solid;width:70%;" ></div></div></a>
    <a class="dropdown-item outline-dec" id="double"   href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">double</div><div style="margin-top:10px;border-top:4px solid;border-style:double;width:70%;" ></div></div></a>
    <a class="dropdown-item outline-dec" id="groove"    href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">groove</div><div style="margin-top:10px;border-top:4px solid;border-style:groove;width:70%;" ></div></div></a>
    <a class="dropdown-item outline-dec" id="ridge"   href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">ridge</div><div style="margin-top:10px;border-top:4px solid;border-style:ridge;width:70%;" ></div></div></a>
    <a class="dropdown-item outline-dec" id="outset"    href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">outset</div><div style="margin-top:10px;border-top:4px solid;border-style:outset;width:70%;" ></div></div></a>
    <a class="dropdown-item outline-dec" id="inset"   href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">inset</div><div style="margin-top:10px;border-top:4px solid;border-style:inset;width:70%;" ></div></div></a>

    
  </div>
</div>
</div>

<input type='number' id="outline_weight_def" value="1" style="text-align:center;width:40px;"/><span style="padding:10px;color:black">px</span>


</div>
<div class="" style="width:100%;padding-left:25px;padding-right:25px;padding-top:10px;">
<div class="dropdown3 outline-change" >
<div style="padding:10px;border-radius:5px;border:2px solid #f2f2f2;">
  <span><div class="outline-init-clr" style="width:40px;height:10px;"></div></span>
</div>
  <div class="dropdown-content3 outline-img-clr" style="width:100%;" >
 <div class="outline-img-sel-clr" acp-color="#EFE9E7" acp-show-rgb="no" acp-show-hsl="no">
</div>
 
  </div>
</div>
</div>



<div style="color:black;font-weight:600;font-size:20px;padding:10px;">
border radius
</div>
<div style="padding:20px;">
<input type="range" min="1" max="100" value="" class="slider" id="myRange">

</div>

<div style="color:black;font-weight:600;font-size:20px;padding:10px;">
Image padding
</div>

<input type='number' id="img_padding_def" value="1" style="text-align:center;width:40px;margin:20px;"/><span style="padding:5px;color:black">px</span>






</div>

<div class='back-res-img' style='display:none;'>



<div style="color:black;font-weight:600;font-size:20px;padding:10px;">
back ground color
</div>

<div class="" style="width:100%;padding-left:25px;padding-right:25px;padding-top:10px;">


<div class="dropdown3 bgclr-change" >


<div style="padding:10px;border-radius:5px;border:2px solid #f2f2f2;">
  <span><div class="bgclr-init-clr" style="width:40px;height:10px;"></div></span>
</div>
  
  
  <div class="dropdown-content3 bgclr-img-clr" style="width:100%;" >
 <div class="bgclr-img-sel-clr" acp-color="#EFE9E7" acp-show-rgb="no" acp-show-hsl="no">
</div>
 
 
 </div>


</div>





</div>


</div>

<div class="style-res-text" style="display:none;width:100%">


<div style="color:black;font-weight:600;font-size:20px;padding:10px;">
text style
</div>

<div class="dropdown" style="width:100%;padding-left:10px;padding-right:10px;">

<button class="borer-type" style="height:40px;background:#f2f2f2;width:100%;background:none;" data-toggle="dropdown"><div style="display:inline-block;width:50%"><div class="" id="font_fam_init" style=""> font family</div> </div><div style="display:inline-block;width:50%;"><i class="fas fa-chevron-down"></i></div></button>
  
  <div class="dropdown-menu" style="border-radius:0px;box-shadow:none;border:1px solid #f2f2f2;width:70%">
    <a class="dropdown-item font-family-dec" id="comic" style="text-align:center;"  href="#"><div class="row" style="margin:0 auto;font-family:'Comic Sans MS', 'Marker Felt-Thin', Arial, sans-serif;font-size:20px;">Comic Sans</div></a>
    <a class="dropdown-item font-family-dec" id="arial" style="text-align:center;"  href="#"><div class="row" style="margin:0 auto;font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;font-size:20px;">Aria</div></a>
    <a class="dropdown-item font-family-dec" id="courier" style="text-align:center;"  href="#"><div class="row" style="margin:0 auto;font-family:'Courier New', Courier, 'Lucida Sans Typewriter', 'Lucida Typewriter', monospace;font-size:20px;">Courier New</div></a>
    <a class="dropdown-item font-family-dec" id="georgia" style="text-align:center;"  href="#"><div class="row" style="margin:0 auto;font-family:Georgia, Times, 'Times New Roman', serif;font-size:20px;">Georgia Times</div></a>
    <a class="dropdown-item font-family-dec" id="helvetica" style="text-align:center;"  href="#"><div class="row" style="margin:0 auto;font-family:'Helvetica Neue', Helvetica, Arial, Verdana, sans-serif;font-size:20px;">Helvetica Neue</div></a>
    <a class="dropdown-item font-family-dec" id="lucida" style="text-align:center;"  href="#"><div class="row" style="margin:0 auto;font-family:'Lucida Grande';font-size:20px;">Lucida Grande</div></a>
    <a class="dropdown-item font-family-dec" id="verdana" style="text-align:center;"  href="#"><div class="row" style="margin:0 auto;font-family:'Verdana';font-size:20px;">Verdana</div></a>
    <a class="dropdown-item font-family-dec" id="tahoma" style="text-align:center;"  href="#"><div class="row" style="margin:0 auto;font-family:'Tahoma';font-size:20px;">Tahoma</div></a>
    <a class="dropdown-item font-family-dec" id="open" style="text-align:center;"  href="#"><div class="row" style="margin:0 auto;font-family:'Open Sans';font-size:20px;">Open Sans</div></a>
    
    

    
  </div>
</div><!-----drop-->

<div style="color:black;font-weight:500;font-size:15px;padding:10px;">
font size
</div>

<div style="padding:10px;">
<input type="range" min="1" max="100" value="" class="slider" id="font_size_init">
<div style="width:100%">
<div style="width:50%; float:left;color:black;">
1 px
</div>
<div style="width:50%;text-align:right;display:inline-block;color:black;">
100 px
</div>
</div>
</div>

<div class="ext_edt_opt">
<div style="color:black;font-weight:500;font-size:15px;padding:10px;padding-top:20px;padding-bottom:20px;">
Extra edit
</div>
<div class="row" style="padding:10px;margin-left:0px;margin-right:0px;width:100%;">
<div style="width:32%">
<div style="padding:10px;border:1px solid #bdbbb9;color:black;border-radius:2px 0px 0px 2px;display:inline-block;border-right:0px;width:40px;text-align:center" class="dec_off" id="bold_init"><i class="fas fa-bold"></i></div><div style="display:inline-block;padding:10px;border:1px solid #bdbbb9;color:black;border-radius:0px 2px 2px 0px;width:40px;text-align:center" class="dec_off" id="italic_init"><i class="fas fa-italic"></i></div>

</div>
<div class="width:25%">

<div class="dropdown3 text-change" style="border:1px solid #bdbbb9;">


<div style="padding:12px;border-radius:5px;border:2px solid #f2f2f2;">
  <span><div class="text-init-clr" style="width:40px;height:10px;"></div></span>
</div>
  
  
  <div class="dropdown-content3 text-img-clr" style="width:100%;" >
 <div class="text-img-sel-clr" acp-color="#EFE9E7" acp-show-rgb="no" acp-show-hsl="no">
</div>
 
 
 </div>


</div>

</div>


<div style="width:43%;text-align:center;">
<div style="padding:10px;border:1px solid #bdbbb9;color:black;border-radius:2px 0px 0px 2px;display:inline-block;border-right:0px;width:40px;text-align:center" class="text_dec_clc dec_off" id="justify"><i class="fas fa-align-justify"></i></div><div style="display:inline-block;padding:10px;border:1px solid #bdbbb9;color:black;border-radius:0px 2px 2px 0px;width:40px;text-align:center" class="text_dec_clc dec_off" id="center"><i class="fas fa-align-center"></i></div>


<div style="padding:10px;border:1px solid #bdbbb9;color:black;border-radius:2px 0px 0px 2px;display:inline-block;border-right:0px;width:40px;text-align:center" class="text_dec_clc dec_off" id="right"><i class="fas fa-align-right"></i></div><div style="display:inline-block;padding:10px;border:1px solid #bdbbb9;color:black;border-radius:0px 2px 2px 0px;width:40px;text-align:center" class="text_dec_clc dec_off" id="left"><i class="fas fa-align-left"></i></div>

</div>



</div>
</div>


<div style="padding:10px;">
<div style="color:black;font-weight:500;font-size:15px;padding-top:20px;padding-bottom:20px;">
line height
</div>
<input type='text' value='' id='lin_height_p' style='width:20%;' />


</div>



</div><!-----style-res-text-->

<div class='back-res-text' style='display:none;'>


<div style="color:black;font-weight:600;font-size:20px;padding:10px;">
back ground color
</div>
<div class="" style="width:100%;padding-left:25px;padding-right:25px;padding-top:10px;">


<div class="dropdown3 bgclr-change" >


<div style="padding:10px;border-radius:5px;border:2px solid #f2f2f2;">
  <span><div class="bgclr-init-clr" style="width:40px;height:10px;"></div></span>
</div>
  
  
  <div class="dropdown-content3 bgclr-img-clr" style="width:100%;" >
 <div class="bgclr-img-sel-clr" acp-color="#EFE9E7" acp-show-rgb="no" acp-show-hsl="no">
</div>
 
 
 </div>


</div>





</div>




</div>


<div class='style-res-btnon' style='display:none;'>


<div style="color:black;font-weight:600;font-size:20px;padding:10px;">
Style of icon
</div>
<div class="dropdown" style="width:50%;padding-left:10px;padding-right:10px;">

<button class="borer-type" style="height:40px;background:#f2f2f2;width:100%;background:none;" data-toggle="dropdown"><div style="display:inline-block;width:100%"><div class="" id="font_fam_init" style=""> <div class='row' style='margin-left:0px;margin-right:0px;'><img id='init_soc_sty' src='../iconfolder/facebook-white.png' width='24' height='24' /><div id='init_soc_sty_txt' style='padding-left:20px;'>white <i style='padding-left:10px;' class="fas fa-chevron-down"></i></div></div></div> </div></button>
  
  <div class="dropdown-menu" style="border-radius:0px;box-shadow:none;border:1px solid #f2f2f2;width:70%">
    <a class="dropdown-item chg_ico_sty" id="white" style="text-align:center;"  href="#"><div class='row' style='margin-left:0px;margin-right:0px;'><img src='../iconfolder/facebook-white.png' width='24' height='24' /><div style='padding-left:20px;'>white</div></div></a>
    <a class="dropdown-item chg_ico_sty" id="round" style="text-align:center;"  href="#"><div class='row' style='margin-left:0px;margin-right:0px;'><img src='../iconfolder/facebook-round.png' width='24' height='24' /><div style='padding-left:20px;'>round</div></div></a>
    <a class="dropdown-item chg_ico_sty" id="grey" style="text-align:center;"  href="#"><div class='row' style='margin-left:0px;margin-right:0px;'><img src='../iconfolder/facebook-grey.png' width='24' height='24' /><div style='padding-left:20px;'>grey</div></div></a>
    <a class="dropdown-item chg_ico_sty" id="square" style="text-align:center;"  href="#"><div class='row' style='margin-left:0px;margin-right:0px;'><img src='../iconfolder/facebook-square.png' width='24' height='24' /><div style='padding-left:20px;'>square</div></div></a>
    <a class="dropdown-item chg_ico_sty" id="outlined" style="text-align:center;"  href="#"><div class='row' style='margin-left:0px;margin-right:0px;'><img src='../iconfolder/facebook-outlined.png' width='24' height='24' /><div style='padding-left:20px;'>outlined</div></div></a>
    <a class="dropdown-item chg_ico_sty" id="outlined_white" style="text-align:center;"  href="#"><div class='row' style='margin-left:0px;margin-right:0px;'><img src='../iconfolder/facebook-outlined_white.png' width='24' height='24' /><div style='padding-left:20px;'>outline white</div></div></a>
    <a class="dropdown-item chg_ico_sty" id="flat" style="text-align:center;"  href="#"><div class='row' style='margin-left:0px;margin-right:0px;'><img src='../iconfolder/facebook-flat.png' width='24' height='24' /><div style='padding-left:20px;'>flat</div></div></a>
    <a class="dropdown-item chg_ico_sty" id="logos" style="text-align:center;"  href="#"><div class='row' style='margin-left:0px;margin-right:0px;'><img src='../iconfolder/facebook-logos.png' width='24' height='24' /><div style='padding-left:20px;'>normal logos</div></div></a>
    
    
    

    
  </div>
</div><!-----drop---->



<div style="color:black;font-weight:600;font-size:20px;padding:10px;">
size of icon
</div>
<div class='' style='padding:20px'>
<a href="#" class="badge  chg_ico_size" id='16px' style='padding:5px;margin:5px;'>16 px</a><a href="#" id='24px' class="badge  chg_ico_size" style='padding:5px;margin:5px;'>24 px</a><a href="#" id='32px' class="badge chg_ico_size" style='padding:5px;margin:5px;'>32 px</a><a href="#" id='48px' class="badge  chg_ico_size" style='padding:5px;margin:5px;'>48 px</a>

</div>



<div style="color:black;font-weight:600;font-size:20px;padding:10px;">
Button align
</div>



<div style="width:43%;text-align:center;">
<div style="padding:10px;border:1px solid #bdbbb9;color:black;border-radius:2px 0px 0px 2px;display:inline-block;border-right:0px;width:40px;text-align:center" class="soc_dec_clc dec_off" id="justify"><i class="fas fa-align-justify"></i></div><div style="display:inline-block;padding:10px;border:1px solid #bdbbb9;color:black;border-radius:0px 2px 2px 0px;width:40px;text-align:center" class="soc_dec_clc dec_off" id="center"><i class="fas fa-align-center"></i></div>


<div style="padding:10px;border:1px solid #bdbbb9;color:black;border-radius:2px 0px 0px 2px;display:inline-block;border-right:0px;width:40px;text-align:center" class="soc_dec_clc dec_off" id="right"><i class="fas fa-align-right"></i></div><div style="display:inline-block;padding:10px;border:1px solid #bdbbb9;color:black;border-radius:0px 2px 2px 0px;width:40px;text-align:center" class="soc_dec_clc dec_off" id="left"><i class="fas fa-align-left"></i></div>

</div>

</div>



<div class='back-res-btnon' style='display:none;'>


<div style="color:black;font-weight:600;font-size:20px;padding:10px;">
back ground color
</div>
<div class="" style="width:100%;padding-left:25px;padding-right:25px;padding-top:10px;">


<div class="dropdown3 bgclr-change" >


<div style="padding:10px;border-radius:5px;border:2px solid #f2f2f2;">
  <span><div class="bgclr-init-clr" style="width:40px;height:10px;"></div></span>
</div>
  
  
  <div class="dropdown-content3 bgclr-img-clr" style="width:100%;" >
 <div class="bgclr-img-sel-clr" acp-color="#EFE9E7" acp-show-rgb="no" acp-show-hsl="no">
</div>
 
 
 </div>


</div>





</div>




</div>


<div class="style-res-hrtag" style="display:none;width:100%">


<div style="color:black;font-weight:600;font-size:20px;padding:10px;">
Anchor text Style
</div>

<div style="color:black;font-weight:500;font-size:15px;padding:10px;padding-top:20px;padding-bottom:20px;">
Anchor color
</div>
<div class="dropdown3 hrtag-change" style="padding:10px;" >


<div style="padding:10px;border-radius:5px;border:2px solid #f2f2f2;">
  <span><div class="hrtag-init-clr" style="width:40px;height:10px;"></div></span>
</div>
  
  
  <div class="dropdown-content3 hrtag-img-clr" style="width:100%;" >
 <div class="hrtag-img-sel-clr" acp-color="#EFE9E7" acp-show-rgb="no" acp-show-hsl="no">
</div>
 
 
 </div>


</div>




<div style="color:black;font-weight:500;font-size:15px;padding:10px;padding-top:20px;padding-bottom:20px;">
text align
</div>



<div style="width:43%;text-align:center;">
<div style="padding:10px;border:1px solid #bdbbb9;color:black;border-radius:2px 0px 0px 2px;display:inline-block;border-right:0px;width:40px;text-align:center" class="href_dec_clc dec_off" id="justify1"><i class="fas fa-align-justify"></i></div><div style="display:inline-block;padding:10px;border:1px solid #bdbbb9;color:black;border-radius:0px 2px 2px 0px;width:40px;text-align:center" class="href_dec_clc dec_off" id="center1"><i class="fas fa-align-center"></i></div>


<div style="padding:10px;border:1px solid #bdbbb9;color:black;border-radius:2px 0px 0px 2px;display:inline-block;border-right:0px;width:40px;text-align:center" class="href_dec_clc dec_off" id="right1"><i class="fas fa-align-right"></i></div><div style="display:inline-block;padding:10px;border:1px solid #bdbbb9;color:black;border-radius:0px 2px 2px 0px;width:40px;text-align:center" class="href_dec_clc dec_off" id="left1"><i class="fas fa-align-left"></i></div>

</div>




<div style="color:black;font-weight:500;font-size:15px;padding:10px;padding-top:20px;padding-bottom:20px;">
Button padding
</div>



<input type='number' id="hrtag_padding_def" value="1" style="text-align:center;width:40px;margin:20px;"/><span style="padding:5px;color:black">px</span>


</div>




<div class="back-res-hrtag" style="display:none;width:100%">


<div style="color:black;font-weight:600;font-size:20px;padding:10px;">
Anchor background Style
</div>

<div style="color:black;font-weight:500;font-size:15px;padding:10px;padding-top:20px;padding-bottom:20px;">
anchor background color
</div>
<div class="dropdown3 hrtag-back-change" style="padding:10px;" >


<div style="padding:10px;border-radius:5px;border:2px solid #f2f2f2;">
  <span><div class="hrtag-back-init-clr" style="width:40px;height:10px;"></div></span>
</div>
  
  
  <div class="dropdown-content3 hrtag-back-img-clr" style="width:100%;" >
 <div class="hrtag-back-img-sel-clr" acp-color="#EFE9E7" acp-show-rgb="no" acp-show-hsl="no">
</div>
 
 
 </div>





</div>

<div style="color:black;font-weight:500;font-size:15px;padding:10px;padding-top:20px;padding-bottom:20px;">
href background radius
</div>


 <div style="padding:10px;">
<input type="range" min="1" max="50" value="" class="slider" id="back_hrtag_size_init">
<div style="width:100%">
<div style="width:50%; float:left;color:black;">
1 px
</div>
<div style="width:50%;text-align:right;display:inline-block;color:black;">
50 px
</div>
</div>
</div>





</div>





<div class="edit-opt-class" id="text" style="display:none;padding-top:20px;">
</div>



<div class="edit-opt-class" id="img" style="display:none">


</div>

<div class="edit-opt-class" id="hrtag" style="display:none">

<div style="color:black;font-weight:600;font-size:20px;padding:10px;">
border radius
</div>
<div class='' style="padding:20px;">
<lable>Enter Url</lable>
<input id='in_hr_link' style='width:100%;height:40px;' type="text"/>
<lable>Ennter anchor text</lable>
<input id='anc_hr_link' style='width:100%;height:40px;' type="text"/>
</div>


</div>







<div class="edit-opt-class" id="rwedt" style="display:none">

<div style="color:black;font-weight:600;font-size:20px;padding:10px;">
border radius
</div>
<div style="padding:20px;">
<input type="range" min="1" max="100" value="" class="slider" id="back_div">

</div>


<div class="dropdown3 bgclr-change" >


<div style="padding:10px;border-radius:5px;border:2px solid #f2f2f2;">
  <span><div class="bgclr-init-clr" style="width:40px;height:10px;"></div></span>
</div>
  
  
  <div class="dropdown-content3 bgclr-img-clr" style="width:100%;" >
 <div class="bgclr-img-sel-clr" acp-color="#EFE9E7" acp-show-rgb="no" acp-show-hsl="no">
</div>
 
 
 </div>


</div>



</div>



<div class="edit-opt-class" id="foo" style="display:none">
</div>

<div class="edit-opt-class" id="bacl-div" style="display:none">


<div class="dropdown3 back-change" style="border:1px solid #bdbbb9;">


<div style="padding:12px;border-radius:5px;border:2px solid #f2f2f2;">
  <span><div class="back-init-clr" style="width:40px;height:10px;"></div></span>
</div>
  
  
  <div class="dropdown-content3 back-img-clr" style="width:100%;" >
 <div class="back-img-sel-clr" acp-color="#EFE9E7" acp-show-rgb="no" acp-show-hsl="no">
</div>
 
 
 </div>


</div>

</div>




</div>



<div class="edit-opt-class" id="btnon" style="display:none">
<div style="width:100%;padding:20px;">

</div>
</div>

<div class="edit-opt-class" id="col-back-img" style="display:none">
<div style="width:100%;padding:20px;">

</div>
</div>



</div><!----edit-content---->
</div><!-----40%-->

</div>


</div><!-----row--->
</div><!----full-conetnt---->


<div id=''   class="edit_foot" style="background:#2d0c2d !important;height:8vh;width:100%;">
<nav class="navbar navbar-expand-sm bg-dark navbar-dark" style="background:#2d0c2d !important;height:8vh;float:right;">
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="#" style="font-weight:700;" id='save'>Save<i class="fad fa-save" style="padding-left:10px;"></i></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" id='save' href="../../template/" style="font-weight:700">Save And Exit<i class="fad fa-sign-out" style="padding-left:10px;"></i></a>
</li>    
    
  </ul>
</nav>
</div>

<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content" style="height:80%;" >
    <div class="modal-header" style='border-bottom:1px solid #dedddc;'>
        <h4 class="modal-title">Select Image</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body"   style='border-bottom:1px solid #dedddc;'>



<div class="row" style='padding:10px;border-bottom:1px solid #dedddc;'>
<div class="dropdown" style=''>
<button style="height:40px;background:#f2f2f2" id="get-dir" data-toggle="dropdown">Folder <span><i class="fas fa-chevron-down"></i></span></button>
  
  <div id="dir_data" class="dropdown-menu" style="width:300px;padding-top:0px;">
  


  </div>
</div><!-----drop-->
<div id="folder_open" style="width:auto;padding:8px;color:#1a73e8;font-size:15px;height:40px;padding-left:30px;"class="">open folder</div></div>




<div id="img-loader3" style="text-align:center;padding-top:100px;display:none;">
<div class="lds-ripple"><div></div><div></div></div>
</div>

<div class="row" id="all-img-con" style="padding-left:30px;width:100%">



</div>




      </div>
      <div class="modal-footer" style="padding:5px;">
      <div class="lkres"></div>
      <div class="upload_img_btn" style="padding:10px;border:1px solid #e8f0fe;">
        <button type="submit" id='sub_img_url'   style="color:#1a73e8;font-weight:500;border:none;background:none" ><span id="load_for_dir" style="padding-right:10px;display:none;"><i class="fa fa-circle-o-notch fa-spin" style="font-size:18px"></i></span><span>Upload image</span></button>
        
        </div>
      </div>
    </div>
  </div>
</div>











<div class="modal fade" id="deleted_modal_open" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <div id='deleted_con_id' style="overflow:scroll"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="bottom-btn" data-dismiss="modal">Close</button>
        <button class="bottom-btn" data-dismiss="modal" style="float:left;background:red;" id='delet_fin_ele2'><i class="fas fa-trash-alt" style="padding-right:10px;"></i>Delet Element</button>
      </div>
    </div>
  </div>
</div>










<!-- Small modal -->

<div class="modal fade" id="select_ele_ele" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Select Content</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
 



<div class="modal-body">
       <form style="margin:0px;" onsubmit="return act_on_sel_ele()">


<div class="row" style="margin:auto;">


<div style="margin:auto;">
<label class="file">

	<div class="con-of-img-sel">

    <div class="midd-sel-img" >
    <i class="fad fa-images"></i>
</div>

<input type="radio"  name="opt_ele_sel" value="img_con" class="sel_data_con_opt">
<span class="file-custom"></span>

</div>
</label>


</div>

<div style="margin:auto;">

  <label class="file">

	<div class="con-of-img-sel">

    <div class="midd-sel-img" >
    <i class="fad fa-align-justify"></i>
</div>

<input type="radio"  name="opt_ele_sel" value="text_con" class="sel_data_con_opt">
<span class="file-custom"></span>

</div>
</label>
</div>

<div style="margin:auto;">



<label class="file">

	<div class="con-of-img-sel">

    <div class="midd-sel-img" >
    <i class="fad fa-rectangle-wide"></i>
</div>

<input type="radio"  name="opt_ele_sel" value="btn_con" class="sel_data_con_opt">
<span class="file-custom"></span>

</div>
</label>

</div>

</div>


<div class="modal-footer">

<input class="bottom-btn" type="submit" style="background: #4a154bd9;" value="set content">


<div>

</form>
      </div>
    </div>
  </div>
</div>

















































</body>









<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>
<script>











p=[];


soc_ico_arr=["facebook","snapchat","tumblr","medium","twitter","instagram","linkedin","reddit","slack","youtube","pinterest","whatsapp","vk","vimeo","viber","telegram","slidshare","periscope","odnoklassniki","google","fbmessenger","blogger"];
tt='';
count_sel_img=0;
op=[];
editopt='';
x=0;
string_edt_opt='ff';
drag_on_div='cc';
back_color='fffff';
text_dsgn="vvvv";
f=0;
type_of_soc_ico='flat';
cls_cn=0;
flag_for_id=0;
drop_con_of_slide='vv';
href_dsgn='njnjj';
select_add_if=null;
id_hg_opt_ico='';


deleted_id='';






$(document).on('click',".hrtag",function(){
	


return false;


});



$(document).on("click","#code_to_edit_trig",function(){


$("#main_ed_con_opt").css('display','none');

$(".code_connect").css("display","block");
$("#code_edit_opt").val($(".main-content").html());
console.log($(".main-content").html());
})
$(document).on("click","#clos_cd_edt",function(){


$(".code_connect").css("display","none");
$("#main_ed_con_opt").css("display","block");


});


$(document).on("change","#code_edit_opt",function(){

$(".main-content").empty();
$(".main-content").html($(this).val());


});







$(document).on("click",".delet_ele",function(){
	console.log(x);
	
	$( "#"+x ).parents().map(function() {

str_cls_del=$(this).attr("class");

if(typeof(str_cls_del)=="string"){
	
	
	if(str_cls_del.includes("down")){
		  		  if(this.id.length>0){
			  deleted_id=this.id;
		  }
	    
     }
}


	});
console.log(deleted_id);

$("#deleted_con_id").html($("#"+deleted_id).html());


});


$(document).on("click","#delet_fin_ele2",function(){
	$("#"+deleted_id).prev().remove();
$("#"+deleted_id).remove();


});








function init_sel_opt_rem(){

$(".sel_data_con_opt").map(function() {

 $(this).siblings(".midd-sel-img").css("background","white");

 $(this).siblings(".midd-sel-img").css("color","black");

$(this).siblings(".midd-sel-img").css("border","1px solid black");
$(this).siblings(".midd-sel-img").css("box-shadow"," 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)");

});


}


$(document).on("change",".sel_data_con_opt",function(){


init_sel_opt_rem();


$(this).siblings(".midd-sel-img").css("color","cadetblue");

$(this).siblings(".midd-sel-img").css("box-shadow","none");

$(this).siblings(".midd-sel-img").css("border","1px solid cadetblue");

});








$(document).on("click",".img_dec_clc",function(){

var stat_of_soc_ico=$(this).attr("id");
$("#"+x).parent().attr("align",stat_of_soc_ico);

$(".img_dec_clc").map(function(){

$(this).removeClass("dec_on");


});
$(this).addClass("dec_on");

});





function init_ele_main(){

$('.col-back-img').map(function() {
    $(this).attr("id",flag_for_id);
  
  flag_for_id+=1;
});



$('.edit').map(function() {
    $(this).attr("id",flag_for_id);
  
  flag_for_id+=1;
});
$('.add_dy_ele').map(function() {
    $(this).attr("id",flag_for_id);
  
  flag_for_id+=1;
});

$('.add_ele').map(function() {
    $(this).attr("id",flag_for_id);
  $(this).attr("ondragstart","drag_con(event,"+flag_for_id+")");
  flag_for_id+=1;
});
}


$(document).on("click",".chg_con_of_md",function(){
	

id_of_selected_man=$(this).parent().attr("id");
     

 
});


function act_on_sel_ele(){


var opt_ele=$('input[name="opt_ele_sel"]:checked').val();



if(opt_ele=='text_con'){



var added_str_ele="<div class='edit text' style='text-align:left;' ><h3>Keanu Reeves Rarly Talks Abount Money- But When He Does It's Life changing.</h3><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries,</P></div>";


}else if(opt_ele=='btn_con'){

var added_str_ele="<a style='background:blue;color:white;border-radius:20px;' href='#' class='edit hrtag'>heptera.me</a>";
}else if(opt_ele='img_con'){


var added_str_ele="<img class='edit img' src='http://heptera.me/dash/main/template/img-log/300*200.png' width='100%' style='height:180px'  />";

}
$("#"+id_of_selected_man).children().html(added_str_ele);
 init_ele_main();
return false;
}

$(document).on("click",".soc_dec_clc",function(){

var stat_of_soc_ico=$(this).attr("id");
$("#"+x).children("table").attr("align",stat_of_soc_ico);

$(".soc_dec_clc").map(function(){

$(this).removeClass("dec_on");


});
$(this).addClass("dec_on");

});




$(document).on("click",".hrtag_dec_clc",function(){

var hrtag_of_soc_ico=$(this).attr("id");
$("#"+x).parent("td").attr("align",hrtag_of_soc_ico);

$(".hrtag_dec_clc").map(function(){

$(this).removeClass("dec_on");


});
$(this).addClass("dec_on");

});





$(document).on("click",'.chg_ico_sty',function(){

id_hg_opt_ico=$(this).attr("id");
type_of_soc_ico=id_hg_opt_ico;

$("#init_soc_sty").attr("src","http://heptera.me/dash/main/template/iconfolder/facebook-"+id_hg_opt_ico+".png");
$("#init_soc_sty_txt").html(id_hg_opt_ico+"<i style='padding-left:10px;' class='fas fa-chevron-down'></i>");

$('.soc_ico').map(function() {
    

if($(this).parent().parent().parent().parent().parent().attr("id")==x){
    var src_of_chg_ico=$(this).children("img").attr("src");
  var main_url_chg_ico=src_of_chg_ico.split("-");
  
  edited_url_of_chg_ico=main_url_chg_ico[0]+"-"+id_hg_opt_ico+".png";
  $(this).children("img").attr("src",edited_url_of_chg_ico)
}
  
});


});

$(document).on("click",".chg_ico_size",function(){


    $('.chg_ico_size').map(function() {
    $(this).removeClass("badge-primary");


});
var current_ico_size=$(this).attr("id");
current_ico_size=current_ico_size.slice(0,-2);


$('.soc_ico').map(function() {

if($(this).parent().parent().parent().parent().parent().attr("id")==x){
    $(this).children("img").attr("width",current_ico_size);
  $(this).children("img").attr("height",current_ico_size);
}
  
});
$(this).removeClass("badge-light");
$(this).addClass("badge-primary");
});


$(document).on("click",".col-back-img",function(){
    $("#con_for_add").css("display","none");

$("."+string_edt_opt).css("display","none");
$(".edit-opt-class").css("display","none");
    $(".note-editor").css("display","none");

    

$("#img-loader2").css("display","block");
 var init_back_img=$(this).css("background-image");

var full_url_img=init_back_img.slice(5);
var full_url_img=full_url_img.slice(0,-2);




p[2]="back_img";


res1 = full_url_img.split("/");

if(full_url_img.search("img-log")==-1){



 

        $.ajax({
  type: "POST",
  url: "../ajaxfile/getimgdata.php",
  data: {img_name_get:res1[7]}
}).done(function(response1) {


   var io= $.parseJSON(response1);


$("#img").html(get_det(io));
$("#img").css("display","block");
    
   
});
}else{
var size_temp_img=res1[6].split(".");

$("#col-back-img").html("<div class='row' style='margin-left:0px;margin-right:0px;'><div style='width:120px;height:120px;margin:20px;'><img src='"+full_url_img+"'  width='120px' height='120px'></div><div style='width:auto'><div style='padding:20px;'><div id='img_edt_name' style='font-size:20px;font-weight:600;color:black'>"+res1[6]+"</div><div class='dime_con' style='padding-top:10px;'><div class='dime'>"+size_temp_img[0]+"</div><div class='size'>temporary image</div></div><div class='edt_opt_img'><span id='5^dW5kZWZpbmU=' data-toggle='modal' data-target='.bd-example-modal-lg' class='edit_opt_img_op getimg img_pre_ld'  style='padding:0px;padding-right:10px;color:blue;'>change</span><span  class='edit_opt_img_op edit_btn' style='color:blue;'>edit</span></div></div></div>");



}


setTimeout(function(){ 

$("#img-loader2").css("display","none");
$("#col-back-img").css("display","block");
},2000);


});



$(document).on("click","#edit1",function(){

     i_flg_for_add_ele=0;
$( "#"+x ).parents().map(function() {
   
    if(i_flg_for_add_ele==0){

  if(this.tagName=='TR'){
class_name_add=$(this).hasClass("down");

if(class_name_add==true){

    i_flg_for_add_ele=1;
    select_add_if=$(this).attr("id");
}



    }

    }
  
  })
var ihi=$( "#"+select_add_if ).clone();

$(ihi).insertAfter( "#"+select_add_if );
$("<tr style='height:10px;'></tr>").insertAfter("#"+select_add_if);

   init_ele_main();
select_add_if=null;
$(".edit1").css("display","none");

});

$(document).on("mouseenter", ".edit", function() {

    
     $('.back_img').map(function() {
    
    
$(this).removeClass('col-back-img');

});
         $('.down').map(function() {
    
    
$(this).removeClass('add_ele');

});
});

$(document).on("mouseleave", ".edit", function() {
      $('.down').map(function() {
    
    
$(this).addClass('add_ele');

});
 $('.back_img').map(function() {
    
    
$(this).addClass('col-back-img');

});

});





$(document).on("click","#back_con_show",function(){
$("."+string_edt_opt).css("display","none");
     $(".edit-opt-class").css("display","none");
    $(".note-editor").css("display","none");

$("#img-loader2").css("display","block");
setTimeout(function(){ 
$("#con_for_add").css("display","block");
$("#img-loader2").css("display","none");
},2000);



})

function allowDrop(ev) {
  ev.preventDefault();
}


function dragEnd(ev) {
   


$('.rt'+cls_cn).map(function() {

 $(this).parent().parent().prev().remove();
 $(this).parent().parent().remove();


});
}

function dragEnd_con(ev2) {
   


$('.rt'+cls_cn).map(function() {

 $(this).parent().parent().prev().remove();
 $(this).parent().parent().remove();


});
}




function drag(ev) {

$('.down').map(function() {
    
    
    $("<tr style='height:10px'></tr><tr class='down add_ele' ><td style='padding-top:0px;padding-bottom:0px;width:100%' style='width:100'><div style='border:2px solid black;width:100%;color:black;min-height:20px;' id='"+flag_for_id+"'  class='rt"+cls_cn+"' ondrop='drop(event)' ondragover='allowDrop(event)'></div></td></tr>").insertAfter(this);

  flag_for_id+=1;
  
});




drag_on_div=ev.target.id+"2";

   
}

function allowDrop_con(ev) {
  ev.preventDefault();

}



function drag_con(ev2,id_for_slide) {

$('.down').map(function() {
    
    
    $("<tr style='height:10px'></tr><tr class='down add_ele' draggable='true' ondragstart='drag_con(event)' id='drag_on2' ondragend='dragEnd_con(event)'><td style='padding-top:0px;padding-bottom:0px;'><div style='border:2px solid black;width:100%;color:black;min-height:20px;' id='"+flag_for_id+"'  class='rt"+cls_cn+"' ondrop='drop_con(event)' ondragover='allowDrop_con(event)'></div></td></tr>").insertAfter(this);

  flag_for_id+=1;
  
});

$('.add_ele').map(function() {
    $(this).attr("id",flag_for_id);
  $(this).attr("ondragstart","drag_con(event,"+flag_for_id+")");
  $(this).addClass("down");
  flag_for_id+=1;
});

drag_on_div=id_for_slide;
   drop_con_of_slide=$("#"+drag_on_div).children().html();



}



function drop_con(ev){
  ev.preventDefault();
  $("#"+drag_on_div).prev().remove();
$("#"+ev.target.id).html(drop_con_of_slide);
  
  

$('.rt'+cls_cn).map(function() {
var len_of_con=$(this).html();

if(len_of_con.length==0){
$(this).parent().parent().prev().remove();
 $(this).parent().parent().remove();
}else{



    $(this).css("border","none");
   
}

});
 

 

 init_ele_main();
  cls_cn+=1;

$("#"+drag_on_div).remove();

}








function drop(ev) {
  ev.preventDefault();
  
 

$("#"+ev.target.id).html($("#"+drag_on_div).html());
  
  


$('.rt'+cls_cn).map(function() {
var len_of_con=$(this).html();

if(len_of_con.length==0){
$(this).parent().parent().prev().remove();
 $(this).parent().parent().remove();
}else{

$(this).attr("on")

    $(this).css("border","none");
   
}

});
 

 init_ele_main();
  cls_cn+=1;
}

$(document).ready(function(){

flag_for_id=0;

       

var get_temp_id='<?php echo $temp_name;?>';



 init_ele_main();



    });


$(document).on("click",".text_dec_clc",function(){
$("#"+text_dsgn).removeClass("dec_on");
$("#"+text_dsgn).addClass("dec_off");


text_dsgn=$(this).attr("id");

$("#"+x).children("p").css("text-align",text_dsgn);
$(this).attr("class","dec_on");
$(this).addClass("text_dec_clc");


});



$(document).on("click",".href_dec_clc",function(){

href_new_align_stat=$(this).attr("id").slice(0,-1);
$(".href_dec_clc").map(function(){
if($(this).attr("id").slice(0,-1)==href_new_align_stat){
$(this).removeClass("dec_off");
$(this).addClass("dec_on");

}else{
$(this).removeClass("dec_on");
$(this).addClass("dec_off");

}


});


$("#"+x).parent().attr("align",href_new_align_stat);



});







$(document).on("click","#bold_init",function(){
var bold_stat=$(this).attr("class");
if(bold_stat=="dec_on"){
$("#"+x).children("p").css("font-weight","400");
$(this).attr("class","dec_off");

}else{

$("#"+x).children("p").css("font-weight","bold");
$(this).attr("class","dec_on");

}

});
$(document).on("click","#italic_init",function(){
var italic_stat=$(this).attr("class");
if(italic_stat=="dec_on"){
$("#"+x).children("p").css("font-style","normal");
$(this).attr("class","dec_off");

}else{

$("#"+x).children("p").css("font-style","italic");
$(this).attr("class","dec_on");

}

});




$(".border-change").click(function(event){
$(".border-img-clr").css("display","block");
event.stopPropagation();


})
$(document).click(function() {
    $(".border-img-clr").css("display","none");
});


$(".outline-change").click(function(event){
$(".outline-img-clr").css("display","block");
event.stopPropagation();


})


$(document).click(function() {
    $(".outline-img-clr").css("display","none");
});


$(".text-change").click(function(event){
$(".text-img-clr").css("display","block");
event.stopPropagation();


})





$(document).click(function() {
    $(".text-img-clr").css("display","none");
});



$(".bgclr-change").click(function(event){
$(".bgclr-img-clr").css("display","block");
event.stopPropagation();


})
$(document).click(function() {
    $(".bgclr-img-clr").css("display","none");
});



$(".hrtag-change").click(function(event){
$(".hrtag-img-clr").css("display","block");
event.stopPropagation();


})
$(document).click(function() {
    $(".hrtag-img-clr").css("display","none");
});


$(".hrtag-back-change").click(function(event){
$(".hrtag-back-img-clr").css("display","block");
event.stopPropagation();


})
$(document).click(function() {
    $(".hrtag-back-img-clr").css("display","none");
});



$(".back-change").click(function(event){
$(".back-img-clr").css("display","block");
event.stopPropagation();


})
$(document).click(function() {
    $(".back-img-clr").css("display","none");
});



AColorPicker.from('.back-img-sel-clr')
.on('change', (picker, color) => {
    $(".border-init-clr").css("background",color);
  $("#"+x).css("background",color);
});



AColorPicker.from('.border-img-sel-clr')
.on('change', (picker, color) => {
    $(".border-init-clr").css("background",color);
  $("#"+x).css("border-color",color);
});



AColorPicker.from('.bgclr-img-sel-clr')
.on('change', (picker, color) => {
    $(".bgclr-init-clr").css("background",color);
  $("#"+x).parent().css("background",color);
});


AColorPicker.from('.outline-img-sel-clr')
.on('change', (picker, color) => {
    $(".outline-init-clr").css("background",color);
  $("#"+x).css("outline-color",color);
});
AColorPicker.from('.text-img-sel-clr')
.on('change', (picker, color) => {
    $(".text-init-clr").css("background",color);
  $("#"+x).children("p").css("color",color);
});


AColorPicker.from('.hrtag-img-sel-clr')
.on('change', (picker, color) => {
    $(".hrtag-init-clr").css("background",color);
  $("#"+x).css("color",color);
});


AColorPicker.from('.hrtag-back-img-sel-clr')
.on('change', (picker, color) => {
    $(".hrtag-back-init-clr").css("background",color);
  $("#"+x).css("background",color);
});








$(document).on("click",".font-family-dec",function(){

var font_fam_get=$(this).attr("id");
if(font_fam_get=="arial"){
$("#"+x).children("p").css("font-family","Arial, 'Helvetica Neue', Helvetica, sans-serif");
$("#font_fam_init").css("font-family","Arial, 'Helvetica Neue', Helvetica, sans-serif");
}else if(font_fam_get=="comic"){
$("#"+x).children("p").css("font-family","'Comic Sans MS', 'Marker Felt-Thin', Arial, sans-serif");
$("#font_fam_init").css("font-family","'Comic Sans MS', 'Marker Felt-Thin', Arial, sans-serif");
}else if(font_fam_get=="courier"){
$("#"+x).children("p").css("font-family","'Courier New', Courier, 'Lucida Sans Typewriter', 'Lucida Typewriter', monospace");
$("#font_fam_init").css("font-family","'Courier New', Courier, 'Lucida Sans Typewriter', 'Lucida Typewriter', monospace");
}else if(font_fam_get=="georgia"){
$("#"+x).children("p").css("font-family","Georgia, Times, 'Times New Roman', serif");
$("#font_fam_init").css("font-family","Georgia, Times, 'Times New Roman', serif");
}else if(font_fam_get=="helvetica"){
$("#"+x).children("p").css("font-family","'Helvetica Neue', Helvetica, Arial, Verdana, sans-serif");
$("#font_fam_init").css("font-family","'Helvetica Neue', Helvetica, Arial, Verdana, sans-serif");
}else if(font_fam_get=="lucida"){
$("#"+x).children("p").css("font-family","'lucida'");
$("#font_fam_init").css("font-family","'lucida'");
}else if(font_fam_get=="verdana"){
$("#"+x).children("p").css("font-family","'verdana'");
$("#font_fam_init").css("font-family","'verdana'");
}else if(font_fam_get=='tahoma'){
$("#"+x).children("p").css("font-family","'tahoma'");
$("#font_fam_init").css("font-family","'tahoma'");
}else if(font_fam_get=="open"){
$("#"+x).children("p").css("font-family","'open sans'");
$("#font_fam_init").css("font-family","'open sans'");
}
});





$(document).on("click",".border-dec",function(){
    
var border_style=$(this).attr("id");

$("#"+x).css("border-style",border_style);
var border_weight=$("#border_weight_def").val();
$("#"+x).css("border-width",border_weight+"px");

});

$(document).on("input change keyup","#border_weight_def",function(){
var border_weight=$("#border_weight_def").val();

$("#"+x).css("border-width",border_weight+"px");

});

$(document).on("input change keyup","#img_padding_def",function(){
var img_padding=$("#img_padding_def").val();

$("#"+x).parent().css("padding",img_padding+"px");

});

$(document).on("input change keyup","#hrtag_padding_def",function(){
var hrtag_padding=$("#hrtag_padding_def").val();

$("#"+x).parent().css("padding",hrtag_padding+"px");
$("#"+x).css("padding",hrtag_padding+"px");

});


$(document).on("click",".outline-dec",function(){
    
var outline_style=$(this).attr("id");

$("#"+x).css("outline-style",outline_style);
var outline_weight=$("#border_weight_def").val();
$("#"+x).css("outline-width",outline_weight+"px");

});

$(document).on("input change keyup","#outline_weight_def",function(){
var outline_weight=$("#outline_weight_def").val();

$("#"+x).css("outline-width",outline_weight+"px");

});

$(document).ready(function(){

var datajson='<?php echo $datavar;?>';
var data_dir=JSON.parse(datajson);
for(i in data_dir){
    var split_dir_name=data_dir[i].dir;
    var data_for_id="'"+split_dir_name+"'";
    var dir_name_on=split_dir_name.split("^");
    
    $("#dir_data").append("<div id="+data_for_id+" class='getimg' ><a  href='#'><i class='fas fa-folder' ></i><span style='padding-left:10px;'>"+atob(dir_name_on[1])+"</span></a><span class='' style='color:black;padding-left:20px;'>"+data_dir[i].count+" files</span></div>");
}


})

var slider = document.getElementById("myRange");

slider.oninput = function() {
  
  $("#"+x).css("border-radius",this.value+"px");
  
}



var slider = document.getElementById("back_div");

slider.oninput = function() {
  
  $("#"+x).css("border-radius",this.value+"px");
  
}



var slider = document.getElementById("font_size_init");


slider.oninput = function() {
  
  $("#"+x).children("p").css("font-size",this.value+"px");
  
}




var slider = document.getElementById("back_hrtag_size_init");


slider.oninput = function() {
  
  $("#"+x).css("border-radius",this.value+"px");
  
}



$(document).on("click",".style-edt-opt",function(){
    $(".note-editor").css("display","none");
 
    $(".back-edt-opt").removeClass("content-edt-opt-active");
$(this).addClass("content-edt-opt-active");
$("."+string_edt_opt).css("display","none");
string_edt_opt="style-res-"+editopt;
$("#img-loader2").css("display","block");
$("#"+editopt).css("display","none");
back_color=$("#"+x).css("background");

$("#color_pick_now").css("background",back_color);

setTimeout(function(){ 
$("."+string_edt_opt).css("display","block");
$("#img-loader2").css("display","none");
},2000);




});



$(document).on("click",".back-edt-opt",function(){
    $(".note-editor").css("display","none");
   
    $(".style-edt-opt").removeClass("content-edt-opt-active");
$(this).addClass("content-edt-opt-active");
$("."+string_edt_opt).css("display","none");
string_edt_opt="back-res-"+editopt;
$("#img-loader2").css("display","block");
$("#"+editopt).css("display","none");
back_color=$("#"+x).css("background");



setTimeout(function(){ 
$("."+string_edt_opt).css("display","block");
$("#img-loader2").css("display","none");
},2000);


});


$(document).on("click", ".edit" , function() {
    $("#col-back-img").css("display","none");
$("."+string_edt_opt).css("display","none");
var back_init=$(this).css("background");
$(".bgclr-init-clr").css("background",back_init);
$("#btnon").empty();
$(".content-edt-opt").removeClass("content-edt-opt-active");





    $('.add_ele').map(function() {
    
    
$(this).css('outline',"none");


});









$("#img-loader2").css("display","block");

    $(".edit-on").removeClass("edit-on");
    
    $(".edit1").css("display", "inline-block");
    $(this).addClass("edit-on");
    x= $(this).attr("id");
     p = document.getElementById(x).classList;
$("#con_for_add").css("display","none");
 editopt=p[1];
 
if(editopt==="text"){

    
$("#lin_height_p").val($("#"+x).css("line-height"));
    $(".note-editor").css("display","block");

var c=$("#"+x).html();
$('#text').summernote({
        placeholder: "holl",
        tabsize: 2,
        height: 100
      });

    
      $(".edit-opt-class").css("display","none");
      $(".note-editor").css("border","none");
      $(".note-editable").html(c);
      $(".note-editable").css("height","300px");
$(".note-editable").css("border","none");
$('.note-editable').on("input change keyup", function() {
  
  
  $('#'+x).html($(".note-editable").html());
});


var font_size_init=$(this).css("font-size");
$("#font_size_init").val(font_size_init.slice(0,-2));
var font_init=$(this).css("font-family");
$("#font_fam_init").css("font-family",font_init);
var font_weight_init=$(this).css("font-weight");
var font_style_init=$(this).css("font-style");

if(font_weight_init=="700"){
    $("#bold_init").addClass("dec_on");
    $("#bold_init").removeClass("dec_off");

}
if(font_style_init=="italic"){
    $("#italic_init").addClass("dec_on");
    $("#italic_init").removeClass("dec_off");
}

var clrintcolor=$(this).css("color");
$(".text-init-clr").css("background",clrintcolor);

setTimeout(function(){ 

$("#img-loader2").css("display","none");
$("#"+editopt).css("display","block");
},2000);







}else if(editopt==="img"){
    $(".edit-opt-class").css("display","none");
    $(".note-editor").css("display","none");
    


    $("#img_padding_def").val($(this).parent().css("padding").slice(0,-2));



var slider_init=$(this).css("border-radius");
slider_init2=slider_init.slice(0,-2);
$("#myRange").val(slider_init2);
var borderintcolor=$(this).css("border-color");
$(".border-init-clr").css("background",borderintcolor);
var outlineintcolor=$(this).css("outline-color");
$(".outline-init-clr").css("background",outlineintcolor);

   

var pres_ico_align=$(this).parent().attr("align");
$(".img_dec_clc").map(function(){
var th_soc_align_id=$(this).attr("id");
if(pres_ico_align==th_soc_align_id){
    $(this).removeClass("dec_off");
    $(this).addClass("dec_on");
}

});


 text_val = $(this).attr("src");




var new_text_src_val=text_val.split("?");
text_val=new_text_src_val[0];


res1 = text_val.split("/");


name_of_ele=res1[res1.length-1];


if(text_val.search("editor")==-1){


console.log(text_val);
 

        $.ajax({
  type: "POST",
  url: "../ajaxfile/getimgdata.php",
  data: {img_name_get:name_of_ele}
}).done(function(response1) {



  console.log(response1);
   var io= $.parseJSON(response1);


$("#img").html(get_det(io));
$("#img").css("display","block");
    
   
});
}else{
var size_temp_img=res1[6].split(".");

$("#img").html("<div class='row' style='margin-left:0px;margin-right:0px;'><div style='width:120px;height:120px;margin:20px;'><img src='"+text_val+"'  width='120px' height='120px'></div><div style='width:auto'><div style='padding:20px;'><div id='img_edt_name' style='font-size:20px;font-weight:600;color:black'>"+res1[6]+"</div><div class='dime_con' style='padding-top:10px;'><div class='dime'>"+size_temp_img[0]+"</div><div class='size'>temporary image</div></div><div class='edt_opt_img'><span id='5^dW5kZWZpbmU=' data-toggle='modal' data-target='.bd-example-modal-lg' class='edit_opt_img_op getimg img_pre_ld'  style='padding:0px;padding-right:10px;color:blue;'>change</span><span  class='edit_opt_img_op edit_btn' style='color:blue;'>edit</span></div></div></div>");



}

setTimeout(function(){ 
$("#"+editopt).css("display","block");
$("#img-loader2").css("display","none");
},2000);









}else if(editopt==="btnon"){
type_of_soc_ico='flat';
    $(".edit-opt-class").css("display","none");
$(".note-editor").css("display","none");

var all_text_of_soc_ico=$("#"+x).find("tr").html();


soc_ico_arr=["facebook","snapchat","tumblr","medium","twitter","instagram","linkedin","reddit","slack","youtube","pinterest","whatsapp","vk","vimeo","viber","telegram","slidshare","periscope","odnoklassniki","google","fbmessenger","blogger"];
var cvb=$(all_text_of_soc_ico).find("td");






$('.soc_ico').map(function() {
    if($(this).parent().parent().parent().parent().parent().attr("id")==x){

pres_soc_ico=$(this).attr("id");
    removeA(soc_ico_arr, pres_soc_ico);
    }
    
  
  
});



    $('.chg_ico_size').map(function() {
    $(this).removeClass("badge-primary");


});


var pres_ico_align=$(this).children("table").attr("align");
$(".soc_dec_clc").map(function(){
var th_soc_align_id=$(this).attr("id");
if(pres_ico_align==th_soc_align_id){
    $(this).removeClass("dec_off");
    $(this).addClass("dec_on");
}

});



var present_width_soc_ico=$("#"+x).find("#"+pres_soc_ico).children("img").attr("width");

$("#"+present_width_soc_ico+"px").removeClass("badge-light");
$("#"+present_width_soc_ico+"px").addClass("badge-primary");
var soc_ico_src_for_type=$("#"+x).find("#"+pres_soc_ico).children("img").attr("src");

var type_with_exe=soc_ico_src_for_type.split("-");

type_of_soc_ico=type_with_exe[1].slice(0,-4);



$("#init_soc_sty").attr("src","http://heptera.me/dash/main/template/iconfolder/facebook-"+type_of_soc_ico+".png");
$("#init_soc_sty_txt").html(type_of_soc_ico+"<i style='padding-left:10px;' class='fas fa-chevron-down'></i>");


str_for_h();









$('.soc_ico').map(function() {


    if($(this).parent().parent().parent().parent().parent().attr("id")==x){
var pres_soc_ico=$(this).attr("id");
    $("#btnon").append(getico_data(pres_soc_ico));
    }
    
  
  
});

$("#btnon").append("<div style='padding:50px;width:100%;'><button style='width:100%;height:40px;background:black;color:white;font-size:20px;font-weight:600;' class='add_soc_icon' id='add_soc_icon_id' >add social icon</button></div>")

setTimeout(function(){ 
$("#"+editopt).css("display","block");
$("#img-loader2").css("display","none");
},2000);


}else if(editopt=="hrtag"){

$(".edit-opt-class").css("display","none");
    $(".note-editor").css("display","none");
var hr_init_text=$(this).text();

$("#back_hrtag_size_init").val($(this).css("border-radius").slice(0,-2));


var hr_init_link=$(this).attr("href");
$("#in_hr_link").val(hr_init_link);
$("#anc_hr_link").val(hr_init_text);
href_dsgn=$("#"+x).parent().css("text-align");

var clrintcolor=$(this).css("color");
$(".hrtag-init-clr").css("background",clrintcolor);
var hrtag_align_stat=$(this).parent().attr("align")+"1";
$(".href_dec_clc").map(function(){
if($(this).attr("id")==hrtag_align_stat){

$(this).removeClass("dec_off");
$(this).addClass("dec_on");

}

});

$("#hrtag_padding_def").val($(this).css("padding").slice(0,-2));


setTimeout(function(){ 
$("#"+editopt).css("display","block");
$("#img-loader2").css("display","none");
},2000);




}else if(editopt='btn-edit'){

var border_radius_btn_edit=$(this).css("border-radius");




}

            
        });






$('#anc_hr_link').on("input change keyup", function() {
  
$("#"+x).html($("#anc_hr_link").val());
  
});



$('#in_hr_link').on("input change keyup", function() {
  
$("#"+x).attr("href",$("#in_hr_link").val());
  
});









$('#lin_height_p').on("input change keyup", function() {
  
$("#"+x).children("p").css("line-height",$("#lin_height_p").val());
  
});




function addconten(v){
   t=t+1;
    $("#"+v).clone().appendTo(".main-content");
    $(".edit").css("border","none");
    
    $("#"+v).attr("id",t);
    
    
}
$("#save").click(function(){
$.post("test2.php",
  {

    content: $(".main-content").html(),
   edited_id: '<?php echo $temp_name;?>'
  },
  function(data,status){
      alert("Data: " + data + "\nStatus: " + status);
    });


});


$(document).on( 'click', '.overlay', function(){

    count_sel_img=count_sel_img+1;
    
   $(this).css("opacity","0.4");


op.push(this.id);

$(this).addClass("select");

});


 
$(document).on( 'click', '.select', function(){
    count_sel_img=count_sel_img-2;

    $(this).css("opacity","0");
    op.splice(op.indexOf(this.id), 1 );
    op.splice(op.indexOf(this.id), 1 );
    
    $(this).removeClass("select");
    
});



img_base_url="https://img.sycista.com/images/";


$(document).on( 'click', '.getimg', function(){
    $("#all-img-con").css("display","none");
    $("#img-loader3").css("display","block");
    $("#all-img-con").empty();
    op=[];
    count_sel_img=0;

 dir_name_1=this.id;
 
 
    
$.ajax({
		url : './ajaxfile/getdirimg.php',
		type: 'POST',
		data : {'dir_name':dir_name_1}
	}).done(function(response){ //
    
    $("#dir_name_for_up").val(dir_name_1);
    var get_res_img=JSON.parse(response);
    $(".res").html(get_res_img[1]);
    $("#folder_open").html(atob(dir_name_1.split("^")[1]));
        $("#upload_img_dir").html(atob(dir_name_1.split("^")[1]));
    for(i in get_res_img){
        $("#all-img-con").append(getconimg(get_res_img[i]));
        
        
    }
    if(response==0){
        $("#all-img-con").append("<div style='text-align:center;width:100%;padding-top:50px;color:'><i style='font-size:100px' class='fas fa-not-equal'></i><div style='font-size:30px;'>Image Not Found</div></div>");
        
    }
    
	});

setTimeout(function(){
$("#all-img-con").css("display","");
$("#img-loader3").css("display","none");

},2000 );



 });





$(document).on("click",".add_soc_icon",function(){
$("#add_soc_icon_id").remove();
var ico_that_add=soc_ico_arr[0];
soc_ico_arr.shift();


$("#btnon").empty();
pres_soc_ico='';
str_for_h();

$('.soc_ico').map(function() {

if($(this).parent().parent().parent().parent().parent().attr("id")==x){

var pres_soc_ico=$(this).attr("id");
    $("#btnon").append(getico_data(pres_soc_ico));
    }



    
  
  
});

$("#"+x).children().children().children().append("<td style='width:6px;' width='6'>&nbsp;</td><td valign='top' align='center'><a href='#' target='_blank' class='soc_ico' id='"+ico_that_add+"' style='text-decoration:none;'><img src='http://heptera.me/dash/main/template/iconfolder/"+ico_that_add+"-"+type_of_soc_ico+".png' alt='yt' style='display:block; font-family:Arial, sans-serif; font-size:14px; line-height:14px; color:#ffffff; max-width:48px;' width='48' border='0' height='48'></a></td>")


$("#btnon").append(getico_data(ico_that_add));





$("#btnon").append("<div style='padding:50px;width:100%;'><button style='width:100%;height:40px;background:black;color:white;font-size:20px;font-weight:600;' class='add_soc_icon' id='add_soc_icon_id' >add social icon</button></div>")
});





$(document).on("click",".rmv_soc_ico",function(){
    
var rmv_id=$(this).parent().attr("id");

rmv_id2=rmv_id.slice(0,-1);
$("#"+rmv_id).remove();
$("#"+x).find("#"+rmv_id2).remove();
soc_ico_arr.push(rmv_id2);

$("#btnon").empty();
str_for_h();

$('.soc_ico').map(function() {

if($(this).parent().parent().parent().parent().parent().attr("id")==x){
var pres_soc_ico=$(this).attr("id");
    $("#btnon").append(getico_data(pres_soc_ico));
    }



    
  
  
});


$("#btnon").append("<div style='padding:50px;width:100%;'><button style='width:100%;height:40px;background:black;color:white;font-size:20px;font-weight:600;' class='add_soc_icon' id='add_soc_icon_id' >add social icon</button></div>")


});




function getico_data(geted_icon_stat){
var val_soc_url=$("#"+x).find("#"+geted_icon_stat).attr("href");





var str_ico_soc="<div class='icon-edt' id='"+geted_icon_stat+'3'+"' style='padding:20px;width:100%;border-bottom:2px solid #f2f2f2;'><div class='rmv_soc_ico soc_ico_dlt' style='width:auto;float:right;'><i class='far fa-trash-alt'></i></div><div class='width:100%;'><div style='display:inline-block;font-size:40px;width:15%'><img src='../iconfolder/"+geted_icon_stat+"-flat"+".png' alt='fb' style='display:block; font-family:Arial, sans-serif; font-size:14px; line-height:14px; color:#ffffff;' width='48' border='0' height='48'></div><div style='display:inline-block;width:80%;'><div class='dropdown drop_menu_open' style='width:100%;padding-left:10px;padding-right:10px;width:100%;'><button class='borer-type' style='height:40px;background:#f2f2f2;width:100%;background:none;' data-toggle='dropdown'><div style='display:inline-block;width:50%'><div class='' id='font_fam_init' style=''>"+geted_icon_stat+"</div></div><div style='display:inline-block;width:50%;'><i class='fas fa-chevron-down'></i></div></button><div id="+geted_icon_stat+'2'+" class='dropdown-menu' style='max-height:400px;overflow-y:scroll;border-radius:0px;box-shadow:none;border:1px solid #f2f2f2;width:70%'>"+tt+"</div></div></div></div><div class='' style='width:100%;font-weight:700;font-size:16px;padding:10px;padding-bottom:0px;font-family:source sans Pro;'>"+geted_icon_stat+" url</div><div style='padding:10px;'><input class='change_url_soc3' id='"+geted_icon_stat+'4'+"' value='"+val_soc_url+"' type='url' style='width:100%;height:40px;'/></div><div class='' style='width:100%;font-weight:700;font-size:16px;padding:10px;padding-bottom:0px;font-family:source sans Pro;'>Text name</div><div style='padding:10px;'><input type='text' class='change_text_soc' style='width:100%;height:40px;'/></div></div>";

return str_ico_soc;

}




$(document).on("click",".chg-ico",function(){
var changed_soc=$(this).attr("id");
var chg_id_soc=$(this).parent().attr("id");
var changed_prop_id=chg_id_soc.slice(0,-1);
removeA(soc_ico_arr, changed_soc.slice(0,-1));

soc_ico_arr.push(changed_prop_id);



$("#"+x).find("#"+changed_prop_id).attr("id",changed_soc.slice(0,-1));
$("#"+x).find("#"+changed_soc.slice(0,-1)).children("img").attr("src","http://heptera.me/dash/main/template/iconfolder/"+changed_soc.slice(0,-1)+"-"+type_of_soc_ico+".png");
    






$("#btnon").empty();
str_for_h();



$('.soc_ico').map(function() {

if($(this).parent().parent().parent().parent().parent().attr("id")==x){
var pres_soc_ico=$(this).attr("id");
    $("#btnon").append(getico_data(pres_soc_ico));
    }



    
  
  
});


$("#btnon").append("<div style='padding:50px;width:100%;'><button style='width:100%;height:40px;background:black;color:white;font-size:20px;font-weight:600;' class='add_soc_icon' id='add_soc_icon_id' >add social icon</button></div>")


});



function removeA(arr) {
    var what, a = arguments, L = a.length, ax;
    while (L > 1 && arr.length) {
        what = a[--L];
        while ((ax= arr.indexOf(what)) !== -1) {
            arr.splice(ax, 1);
        }
    }
    return arr;
}


function str_for_h(){
tt='';

var len_of_soc=soc_ico_arr.length

for (i = 0; i < len_of_soc; i++) {
    tt += "<a class='dropdown-item outline-dec chg-ico' id='"+soc_ico_arr[i]+'1'+"'   href='#'>"+soc_ico_arr[i]+"</a>";
  }

}

$(document).on("input change keyup",'.change_url_soc3', function() {
  
  var url_id_soc=$(this).attr("id");
 
$("#"+x).find("#"+url_id_soc.slice(0,-1)).attr("href",$(this).val());

});





function getconimg(url_img){
    d = new Date();
var con_img="<div class='img-con'><img class='imag-cls' src='"+img_base_url+url_img+"?"+d.getTime()+"' alt='Avatar' class='image'><div class='overlay'  id='"+url_img+"' ><div class='text56'><i class='far fa-minus-square' style='font-size:30px;color:black;'></i></div></div></div>";
return con_img;

}

$(document).on("click","#sub_img_url",function(){
t = new Date();

var src_img_res=img_base_url+op[0]+"?"+t.getTime();
if(p[2]=="back_img"){

$("#"+x).css("background-image","url("+src_img_res+")")


}else{
$("#"+x).attr("src",src_img_res);

}

$(".lkres").html("ravi");
text_val="../studio/ajaxfile/images/"+op[0]+"?"+t.getTime();
 $.ajax({
  type: "POST",
  url: "../ajaxfile/getimgdata.php",
  data: {img_name_get:op[0]}
}).done(function(response1) {


   var io= JSON.parse(response1);
if(p[2]=='back_img'){

$("#col-back-img").html(get_det(io));

}else{
$("#img").html(get_det(io));

}


$("#img").css("display","block");
    
   
});


});
$(document).on("click",".edit_btn",function(){

const ImageEditor = new FilerobotImageEditor();
b = new Date();
  ImageEditor.open(text_val+'?'+b.getTime());
  
$(".sc-kEYyzF").html("<a href='#' class='savelink' id='img_edt_sub'  style='float:right;text-align:center;color:white;text-decoration:none;font-weight:200;' onclick='sub()'>Save Changes</a>");

});

function get_det(var_data_img){

d = new Date();
var resimg='<div class="edit-opt-class" id="img" style="display: block;"><div class="row" style="margin-left:0px;margin-right:0px;"><div style=" width: 30%; padding: 10px; "><img src="'+img_base_url+var_data_img.image+"?"+d.getTime()+'" style=" width: 70%; margin-top: 12.5%; "></div><div style="width: 70%;"><div style="padding: 10px;"><div id="img_edt_name" style="font-size: 13px;font-weight:600;color:black;">'+var_data_img.org_name+'</div><div class="dime_con" style="padding-top:10px;"><div class="dime">'+var_data_img.width+"*"+var_data_img.height+'</div><div class="size">'+var_data_img.size+'</div></div><div class="edt_opt_img"><span id="5^dW5kZWZpbmU=" data-toggle="modal" data-target=".bd-example-modal-lg" class="edit_opt_img_op getimg img_pre_ld" style="padding:0px;padding-right:10px;color:blue;">change</span><span class="edit_opt_img_op edit_btn" style="color:blue;">edit</span></div></div></div></div></div>';
return resimg;
}

</script>

</html>

<?php 

}


}else{
?>
<meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<script src="./../../assets/js/plugins/jquery/dist/jquery.min.js"></script>
<link href="./../../assets/css/argon-dashboard.css?v=1.1.0" rel="stylesheet" />

<style>
.extracardcss{
     margin:auto;
margin-top:18%;
}

</style>
<body style="background:#f8f9fe;">


<div class="extracardcss card" style="width: 18rem;">
  
  <div class="card-body">
    <h5 class="card-title"><div class="navb">heptera|<sub>mail</sub></div></h5>
    <p class="card-text">For verify Your email adress please click on button and please verify your account</p>
    <input type="checkbox" id="terms" required> I accsept terms and condition.<br>
    <button id="sendlink" class="btn btn-warning" style="margin-top:25px" ><i id="loadsendlink" class="fa fa-circle-o-notch fa-spin" style="display:none"></i> send verify link</button>
  </div>
</div>













<script>
$(document).ready(function(){
  $("#sendlink").click(function(){
      var email="<?php echo $mail;?>"
      var id="<?php echo $id;?>"
      $("#loadsendlink").css("display","inline-block");
      
    $.ajax({
		url : "http://dash.heptera.me/ajaxphp/sendlink.php",
		type: "POST",
		data : "email="+email
	}).done(function(response){ //
        $("#loadsendlink").css("display","none");
		$("#sendlink").html(response);
        
	});
  });
});





</script>




<?php

}}else{
    header("location:http://heptera.me/login.php");
}
?>

