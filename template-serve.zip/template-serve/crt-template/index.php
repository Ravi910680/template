<?php
session_start();

$mail=$_SESSION['email'];
$id=$_SESSION['id'];
?>


<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">
 <link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css" rel="stylesheet" />
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1603531914/norm_used/loader_ww3kih.css">
<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet"> 
<style>

@import url(https://fonts.googleapis.com/css?family=Josefin+Sans);
@import url(https://fonts.googleapis.com/css?family=Arvo);
.tablediv{
    padding:10%;
}

.ico-temp{
    margin:10px;
    color:#2643e9;
    
}

a .open_in_edit{
  color: #5e72e4 !important;
}
.ico-temp:hover{
cursor:pointer;

}
.btn_of_res:hover{
    cursor:pointer;
}


.temp_con {
    padding: 20px;
    width: fit-content;
    border-radius: 5px;
    border: 1px solid #f2f2f2;
    margin-bottom: 20px;
    background: white;
    transition: .5s;
    box-shadow: 0 0 2rem rgba(0,0,0,.1);

    }
.temp_con:hover {
    cursor: pointer;
    box-shadow: 0 0 2rem rgba(0,0,0,.2);
    transform: scale(1.05);

  }
.row{
margin-left:0px;
margin-right:0px;
}

.temp_name_sty{
padding-top: 10px;
background:white;
    color: #341161;
    font-family: 'Nunito Sans','Avenir Next','Segoe UI','Open Sans','Helvetica Neue',Helvetica,Arial,sans-serif;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-size: 17px;
    font-weight: 540;
    letter-spacing: 0.8px;
    padding-bottom:10px;
    text-align: center;
}
.btn-my:hover{
    outline:2px solid;
    cursor:pointer;

}
.card:hover{
    cursor:default;
}
.btn-my{
    height:50px;text-align:center;background:#f2f2f2;border:none;
    
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}
.nav-link:hover{
    cursor:pointer;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}
.addsiteheadbtn:hover{
    color:black;
    cursor:pointer;
    background:#d9d7cd;

}

#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}






.res_of_hepta {
    padding: 10px;
    background: #0700ff1f;
    color: black;
    font-weight: 600;
    border-radius: 5px;
    border: 4px solid #0008ff4f;
display:none;


}


body{




webkit-font-smoothing: antialiased;}
.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}
.modal-text p{


font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;



}
.modal-btn:hover{
transition:background-color 0.2s ease-in-out 0s, opacity 0.2s ease-in-out 0s;
cursor:pointer;
background:#2296a3;

}
.modal-btn{

border:none;
outline:none;
height:40px;
font-size:15px;
letter-spacing:0.6px;
color:white;
padding-left:10px;
padding-right:10px;
background:#007c89;
font-weight:900;
}

.modal-text{
font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
padding-right:100px;
text-align: left;
    padding-left: 100px;
    padding-top: 40px;
    padding-bottom: 40px;
}
button:focus{
    outline:none;
}






@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}
.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    float: right;
    padding-left: 20px;
    padding-right: 20px;
}
.bottom-btn:hover{
	cursor: pointer;
}

.bottom-btn:focus{
  outline: none !important;
}
.bottom-btn:active{
  outline: none !important;
}








button.btn_hover_clr {
    margin-top: 10px;
    background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    font-size: 13px;
    font-weight: 500;
    float: right;
    color: #471f48f0;

  }

  button.btn_hover_clr:hover {
    background: #b284b336;
    cursor: pointer;

  }











.lds-color div{

border: 2px solid #4a154bd9;border-color: #4a154bd9 transparent transparent transparent !important;

}


.lds-pos-cht{

  top: 50%;
  left: 50%;
}

.lds-pos-bg{
top: 50%;

}

.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid white;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: white transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

.lds-large div{
  width: 40px;
  height: 40px;
  border: 4px solid;

}



.lds-large {
    margin: auto;
    
    width: 40px;
    height: 40px;

  }

.main-content {
  height: 92vh;
  overflow: scroll;
}

   .lds-main-large{
top: 300px;
    left: 50%;

  }





button.btn-theme-dsg {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    font-size: 14px;
    line-height: 1.5;
    font-weight: 500;
    border-radius: 4px;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    border: 0;
    -webkit-appearance: none;
    position: relative;
    -webkit-transition-property: background-color,border-color,color;
    transition-property: background-color,border-color,color;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
    min-width: 0;
    -webkit-flex: 0 0 auto;
    -ms-flex: 0 0 auto;
    flex: 0 0 auto;
    font-family: 'Roboto';
    color: #FFFFFF;
    background-color: #4a154b;
    padding-right: 16px;
    padding-left: 16px;
    margin: 8px 0px;
    height: 48px;


  }

  .modal{
    z-index: 10000000000;
  }


  .ip-by-def-dsg {
    width: 100%;
    background-color: #FFFFFF;
    height: 48px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    margin: 8px 0px;
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;


  }

  .ip-by-def-dsg:focus {
    background-color: #fff;
    outline: 0;
    border-color: #4a154b;
    box-shadow: 0 0 0 3px #4a154b4d;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;

  }



button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}



.modal-2 {
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 0vh;
  background-color: transparent;
  overflow: hidden;
  transition: background-color 0.25s ease;
  z-index: 9999;
}
.modal-2.open {
  position: fixed;
  width: 100%;
  height: 100vh;
  background-color: rgba(0, 0, 0, 0.5);
  transition: background-color 0.25s;
}
.modal-2.open > .content-wrapper {
  transform: scale(1);
}
.modal-2 .content-wrapper {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  width: 40%;
  margin: 0;
  padding: 2.5rem;
  background-color: white;
  border-radius: 0.3125rem;
  box-shadow: 0 0 2.5rem rgba(0, 0, 0, 0.5);
  transform: scale(0);
  transition: transform 0.25s;
  transition-delay: 0.15s;
}
.modal-2 .content-wrapper .close {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 2.5rem;
  height: 2.5rem;
  border: none;
  background-color: transparent;
  font-size: 1.5rem;
  transition: 0.25s linear;
}
.modal-2 .content-wrapper .close:before, .modal-2 .content-wrapper .close:after {
  position: absolute;
  content: '';
  width: 1.25rem;
  height: 0.125rem;
  background-color: black;
}
.modal-2 .content-wrapper .close:before {
  transform: rotate(-45deg);
}
.modal-2 .content-wrapper .close:after {
  transform: rotate(45deg);
}
.modal-2 .content-wrapper .close:hover:before, .modal-2 .content-wrapper .close:hover:after {
  background-color: tomato;
}
.modal-2 .content-wrapper .modal-2-header {
  position: relative;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  margin: 0;
  padding: 0 0 1.25rem;
}
.modal-2 .content-wrapper .modal-2-header h2 {
  font-size: 1.5rem;
  font-weight: bold;
}
.modal-2 .content-wrapper .content {
  position: relative;
  display: flex;
}
.modal-2 .content-wrapper .content p {
  font-size: 0.875rem;
  line-height: 1.75;
}
.modal-2 .content-wrapper .modal-2-footer {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  width: 100%;
  margin: 0;
  padding: 1.875rem 0 0;
}
.modal-2 .content-wrapper .modal-2-footer .action {
  position: relative;
  margin-left: 0.625rem;
  padding: 0.625rem 1.25rem;
  border: none;
  background-color: slategray;
  border-radius: 0.25rem;
  color: white;
  font-size: 0.87rem;
  font-weight: 300;
  overflow: hidden;
  z-index: 1;
}
.modal-2 .content-wrapper .modal-2-footer .action:before {
  position: absolute;
  content: '';
  top: 0;
  left: 0;
  width: 0%;
  height: 100%;
  background-color: rgba(255, 255, 255, 0.2);
  transition: width 0.25s;
  z-index: 0;
}
.modal-2 .content-wrapper .modal-2-footer .action:first-child {
  background-color: #2ecc71;
}
.modal-2 .content-wrapper .modal-2-footer .action:last-child {
  background-color: #e74c3c;
}
.modal-2 .content-wrapper .modal-2-footer .action:hover:before {
  width: 100%;
}






.modal-2-header h2{

  color: black;
}





#main-loader-containre-act{


    text-align: center;
    padding-top: 41vh;
  }

.main-loader-containre-act{
  text-align: center;padding-top: 41vh;height: 84vh;
}


a {
    color: #5e72e4 !important;


  }


</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->

<link href='https://fonts.googleapis.com/css?family=Karla:700' rel='stylesheet' type='text/css'>
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  

 
  <!-- CSS Files -->
 
</head>
<div id="c"></div>
<body class="" style="">
  <?php require("../confige/header/header.php");?>

<div class="main-content" id='main-loader-containre'>



<div class="full-mdl-con-lrg" style="
    border-radius: 0px;
    background: #eef0f1;
    margin: auto;
">
    
        <div class="tw-rw-mdl-con" style="padding:0px;">

    <img src="https://res.cloudinary.com/heptera/image/upload/v1603553488/template/Email_campaign-bro_mjjgnp_xhlofv.svg" style="width: 100%;margin-top: auto;height: 100%;">
    
</div>
        <div class="tw-rw-mdl-con">
 
    
    <div style="font-size:30px;font-family: 'Karla', sans-serif;color: #350835;text-align:center;width:100%;letter-spacing: 0px;">
Create Template
</div>
    
    <div style="text-align:center">
<div class="row">
<div class="" style="padding:20px;width:50%;float:right;">
<a class="red_norm_url" red-url-dt="../../studio/"><button class="btn_hover_clr" style="
    background: white;
"><i class="fal fa-camera-retro" aria-hidden="true" style="padding-right: 10px;"></i>Go To Studio</button></a></div>

<div class="" style="padding:20px;width:50%;float:left;">
<a class="red_norm_url" red-url-dt="../../template/"><button class="btn_hover_clr" style="float:left;background: #350835;color: white;border: none;"><i class="fal fa-list-alt" style="padding-right: 10px;"></i>All Template</button></a></div>
</div>
</div>


<p class="mdl-lrg-notc-txt" style="
    width: 40;
    width: 50%;
    margin: auto;
">Create Your New email template Without more stuff and easily deploy in Sycista System.</p>

<button class="btn-theme-dsg" id="click_to_con" type="submit" style="
    float: none;
    width: 60%;
    margin: auto;
    margin-top: 40px;
"><span>Explore More About Template</span><i class="fal fa-long-arrow-right" style="padding-left:10px;"></i></button>

</div>
        
    
    
    </div>












<div style='width:100%;padding-top:3%;padding-bottom:5%;padding-right:15%;padding-left:15%;' >



<div class="res_of_hepta" id='res_of_proc'>
    
</div>




<div style=''>
<span class="ico-temp badge badge-pill badge-primary" >all</span><span class="ico-temp badge badge-pill badge-light">basics</span><span class="ico-temp badge badge-pill badge-light">brand</span><span        class="ico-temp badge badge-pill badge-light">bussiness</span><span class="ico-temp badge badge-pill badge-light">eCommers</span></div>

<div class='' id='load_for_temp' style='text-align:center;padding-top:40px;padding-bottom:20px;font-size:50px;'><i class="fas fa-circle-notch fa-spin"></i></div>
<div id='temp_res_of_con' style=''>
<div class="row" id='temp_to_res' style="display:;">










</div>
</div>


</div>


</div>


<div id='res'>
</div>

<style type="text/css">

.full-mdl-con-lrg {
    width: 100%;
    height: 60vh;
    background: white;
border-radius: 10px;
  }

  .tw-rw-mdl-con {
    width: 49.7%;
    height: 60vh;
    display: inline-block;
    overflow: scroll;
    padding: 40px;
  }
  p.mdl-lrg-notc-txt {
    font-size: 13px;
    color: #565454;
    font-weight: 500;
    }

</style>

<!-- Modal -->
<div  class="modal-2" data-modal="exampleModalCenter" >
  <div class="modal-dialog modal-dialog-centered" style='max-width:70%;' role="document">
    <div class="modal-content" style=''>

      
      
<div class="full-mdl-con-lrg">
    
        <div class="tw-rw-mdl-con" style="padding:0px;">

    <img src="https://res.cloudinary.com/heptera/image/upload/v1603549263/template/Email_campaign-bro_mjjgnp_fwrz7k.svg" style="width: 100%;margin-top: auto;height: 100%;">
    
</div>
        <div class="tw-rw-mdl-con">

<button class="close" style='width:fit-content;'><i class="fal fa-times-circle"></i></button>
    
    <div style="width:100%;text-align:center;overflow: scroll;">

<div class="" style="text-align:left">
<h2 style="color:black;font-size:20px">Create new Template</h2>
<p class='mdl-lrg-notc-txt'>Enter Valid email template name for your sutable audiance well design Template give high response.</p>
<div style="padding:20px 3px;">

<label style="font-weight:450;color:black;letter-spacing:0.6px;">Create Template</label>
        <input class="ip-by-def-dsg" id="id_for_temp_name" name="nameofnewlist" type="text" style="" required="">

<div style="color:red;font-weight:500;" class="res"></div>

          
         
<div style="padding-top:40px;text-align:center">
<button class="btn-theme-dsg" id="click_to_con" type="submit" style="
    float: none;
"><span style="padding-right:10px;display:none;" id="crt_temp_load"><i class="fas fa-circle-notch fa-spin"></i></span><span>Get Template</span><i class="fal fa-long-arrow-right" style="padding-left:10px;"></i></button>
</div>       

</div>
</div>
</div>
    
    

</div>
        
    
    
    </div>
      
    
    </div>
  </div>
</div>



<div class="modal fade" id="temp_review_con" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document" style='max-width:700px;'>
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="ovw_of_temp_name">Delet Template</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div id='temp_data_md'></div>
      </div>
      <div class="modal-footer">
       
       <a href='#' id='href_for_ovw_edit'> <button type="button" class='btn_hover_clr'  ><span style='padding-right:10px;display:none' id='del_load'><i class="fas fa-circle-notch fa-spin" style=''></i></span>Edit Template</button></a>
      </div>
    </div>
  </div>
</div>




  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>
  
  <!--   Optional JS   -->
  
  <!--   Argon JS   -->
  <script>
  

template_name={all:['salted','simple','blog post','webinar','verify','feature','flexible','invite','progress','welcome offer','update','confirm','portfolio','welcome','cold leads'],basics:['salted','simple','blog post','webinar','verify','feature','flexible'],eCommers:['invite','progress','welcome offer','update','confirm'],brand:['portfolio','welcome'],bussiness:['cold leads']};

main_url_of_page='http://heptera.me/dash/main/template/edit/temp-base/';

decode_name_of_temp='';
name_of_temp='';



function sel_opt_of_tp_temp(passed_tp){


for (var i = 0; i < template_name[passed_tp].length; i++) {
  
temp_thumb(template_name[passed_tp][i]);

};


}







$(document).on("click",".ico-temp",function(){
	
	
$(".ico-temp").map(function(){

$(this).removeClass("badge-primary");
$(this).addClass("badge-light");

});
	
	
	$(this).removeClass("badge-light");
$(this).addClass("badge-primary");


});













$(document).ready(function(){

    
    console.log(template_name['basics']);


    
    
 sel_opt_of_tp_temp('all');   
    
    
    $("#load_for_temp").css("display","none");
 
	



});
$(".clickforcat").click(function(){

$("#res").html(basics[$(this).attr("id")][0]);

})

function temp_thumb(temp_id){

var encoded_temp_name=window.btoa(temp_id);


var str_for_temp_res="<div  class='' style='padding-right:0px;padding-left:0px;margin:auto;'><div class='temp_con'><img id='img-of-temp' class='temp_img_con' data-toggle='modal' data-target='#temp_review_con' src='http://via.placeholder.com/200x200' width='200' height='250' id='"+encoded_temp_name+"' /><div class='temp_name_sty'>"+temp_id+"</div><div style='width:100%;padding:10px;border-top:1px solid #D6E3E3;'><div class='row' style='text-align:center;'><div style='width:100%;text-align:center;'><a class='open_in_edit trigger' href='#' id='"+encoded_temp_name+"' data-modal-trigger='exampleModalCenter'>open in Editor <i class='far fa-sign-out-alt' style=' padding-left: 10px; '></i></a></div></div></div></div></div></div>";

$("#temp_to_res").append(str_for_temp_res);



get_screen_shot(encoded_temp_name);

}

$(document).on("click",".ico-temp",function(){

$("#temp_to_res").empty();

$("#load_for_temp").css("display","block");
sel_opt_of_tp_temp($(this).html());

$("#load_for_temp").css("display","none");


});

function get_screen_shot(id_of_url){
  
    url=main_url_of_page+id_of_url+".html";
  url_main="http://ec2-3-21-105-231.us-east-2.compute.amazonaws.com/scr-api/?url="+url+"&width=700&height=800"; 



    $("#img-of-temp").attr("src",url_main);
    $("#img-of-temp").attr("id",id_of_url);

//document.getElementById(id_of_url+"img").src=url_main;

console.log(id_of_url);
}







$(document).on("click",".temp_img_con",function(){

var id_of_temp=$(this).attr("id");
$("#ovw_of_temp_name").html(atob(id_of_temp));
$("#temp_data_md").load('../edit/temp-base/'+id_of_temp+".html");
$("#href_for_ovw_edit").attr("href","./edit/?editor_id="+id_of_temp);

});


	
$(document).on("click",".open_in_edit",function(){

decode_name_of_temp=$(this).attr("id");

modalEvent(this);




});

$(document).on("click","#click_to_con",function(){
	name_of_temp=$("#id_for_temp_name").val();

	if(name_of_temp.length>0){
$("#crt_temp_load").css("display","inline-block");
id='<?php echo $id;?>';

$(this).prop('disabled','true');
$(this).html('<div class="cp-spinner cp-round"></div>');

        $.ajax({
  type: "POST",
  url: "ajaxfile/vertempname.php",
  data: {temp_name_get:name_of_temp,type_temp:decode_name_of_temp,temp_crt_flg:1,path:"../../edit/temp-base/"}
}).done(function(response1) {
  if(response1==1){
	  temp_en_name=id+"^"+btoa(name_of_temp);
	  window.location.href='../edit/?editor_id='+temp_en_name;
  }else{

	  err_msg_data("Please Try Again");
  }   
});

	}else{

err_msg_data("Enter Valid Name");
	}


});





$(document).on("click",".red_norm_url",function(){


red_url=$(this).attr("red-url-dt");


red_url_load_fun(red_url);

})


function red_url_load_fun(red_url){


$(".main-content").empty();



append_load_main_large(".main-content");



window.location.href =red_url;

}


function append_load_main_large(ele){

$(ele).html("<div class='lds-ring lds-color lds-large lds-main-large' id='lds-for-all-temp' style=''><div></div><div></div><div></div><div></div></div>");

}







function modalEvent(button) {

  
    const trigger = button.getAttribute('data-modal-trigger');

    console.log(trigger)
    const modal = document.querySelector(`[data-modal=${trigger}]`);
    const contentWrapper = modal.querySelector('.content-wrapper');
    const close = modal.querySelector('.close');

    close.addEventListener('click', () => modal.classList.remove('open'));
    

    modal.classList.toggle('open');
  
}







append_txt_that_get_clck="";



function append_load_in_all_btn(selector){




append_txt_that_get_clck=$(selector).html();

$(selector).prop("disabled",true);

$(selector).html('<div class="cp-spinner cp-round"></div>');

}



function append_txt_of_lds(selector){

$(selector).prop("disabled",false);

$(selector).html(append_txt_that_get_clck);


}




function err_msg_data(message){


$("#con-of-err-msg").html(message);

$("#err_msg_dt_trg").css('display','inline-block');



setTimeout(
    function() {


      $("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');
      
    }, 5000);


}



$(document).on('click','#cncl-err-msg',function(){


$("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');

})


</script>
  
  
</body>

<script type="text/javascript" src="../jsfile/stickyheader4.js">

</script>



</html>


