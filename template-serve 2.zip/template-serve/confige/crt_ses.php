<?php

session_start();


$_SESSION['id']=$_GET['id'];

$_SESSION['email']=$_GET['email'];



header("Location: ".$_GET['url_red']);

?>