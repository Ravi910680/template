<?php
$filecreateflag=file_put_contents("../crt-template/crtedtemp/".$_POST['edited_id'].".html", $_POST["content"]);




echo $filecreateflag;
?>
