<?php


error_reporting(E_ALL ^ E_WARNING); 



?>

















<div style="background-color:transparent;">
<div class="block-grid mixed-two-up" style="Margin: 0 auto; min-width: 320px; max-width: 605px; overflow-wrap: break-word; word-wrap: break-word; word-break: break-word; background-color: transparent;">
<div style="border-collapse: collapse;display: table;width: 100%;background-color:transparent;">

<div class="col-new num4" style="display: table-cell; vertical-align: top; max-width: 320px; min-width: 200px; width: 201px;">
<div style="width:100% !important;">

<div style="border-top:0px solid transparent; border-left:0px solid transparent; border-bottom:0px solid transparent; border-right:0px solid transparent; padding-top:5px; padding-bottom:5px; padding-right: 0px; padding-left: 0px;">

<div align="center" class="img-container center autowidth" style="padding-right: 0px;padding-left: 0px;">
<a href="<?php echo $_GET['url'];?>"><img align="center" alt="Alternate text" border="0" class="center autowidth" src="<?php echo $_GET['img'];?>" style="text-decoration: none; -ms-interpolation-mode: bicubic; height: auto; border: 0; width: 100%; max-width: 200px; display: block;" title="Alternate text" width="100"></a>

</div>

</div>

</div>
</div>

<div class="col-new num8" style="display: table-cell; vertical-align: top; min-width: 320px; max-width: 400px; width: 403px;">
<div style="width:100% !important;">

<div style="border-top:0px solid transparent; border-left:0px solid transparent; border-bottom:0px solid transparent; border-right:0px solid transparent; padding-top:5px; padding-bottom:5px; padding-right: 0px; padding-left: 0px;">

<div style="color:#555555;font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;line-height:1.2;padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px;">
<div style="line-height: 1.2; font-size: 12px; color: #555555; font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif; mso-line-height-alt: 14px;">
<a href="<?php echo $_GET['url'];?>"><h1 style="
    font-family: 'Roboto', sans-serif;
    margin: 0px;
    color: #000000;
"><?php echo $_GET['title'];?></h1></a>

<a href="<?php echo $_GET['url'];?>"><p style="font-size: 14px; line-height: 1.2; word-break: break-word; mso-line-height-alt: 17px; margin: 0;"><?php echo $_GET['text'];?></p></a>

</div>
</div>

</div>

</div>
</div>

</div>
</div>
</div>


























