<div style="color:black;font-weight:600;font-size:20px;padding:10px">
Border setting
</div>
<div class="row" style="padding:25px;">
<div style="width:50%">
<div class="dropdown" style="width:100%;padding-left:10px;padding-right:10px;">

<button class="borer-type" style="height:40px;background:#f2f2f2;width:100%;background:none;" data-toggle="dropdown">border type <span><i class="fas fa-chevron-down"></i></span></button>
  
  <div class="dropdown-menu" style="border-radius:0px;box-shadow:none;border:1px solid #f2f2f2;width:100%">
    <a class="dropdown-item border-dec" id="none"    href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">none</div><div style="margin-top:10px;width:70%;" ></div></div></a>
    <a class="dropdown-item border-dec" id="dotted"    href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">dotted</div><div style="margin-top:10px;border-top:4px solid;border-style:dotted;width:70%;" ></div></div></a>
    <a class="dropdown-item border-dec" id="dashed"    href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">dashed</div><div style="margin-top:10px;border:none;border-top:4px;border-style:dashed;width:70%;" ></div></div></a>
    <a class="dropdown-item border-dec" id="solid"   href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">solid</div><div style="margin-top:10px;border-top:4px solid;border-style:solid;width:70%;" ></div></div></a>
    <a class="dropdown-item border-dec" id="double"    href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">double</div><div style="margin-top:10px;border-top:4px solid;border-style:double;width:70%;" ></div></div></a>
    <a class="dropdown-item border-dec" id="groove"    href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">groove</div><div style="margin-top:10px;border-top:4px solid;border-style:groove;width:70%;" ></div></div></a>
    <a class="dropdown-item border-dec" id="ridge"    href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">ridge</div><div style="margin-top:10px;border-top:4px solid;border-style:double;width:70%;" ></div></div></a>
    <a class="dropdown-item border-dec" id="inset"    href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">inset</div><div style="margin-top:10px;border-top:4px solid;border-style:inset;width:70%;" ></div></div></a>
    <a class="dropdown-item border-dec" id="outset"    href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">outset</div><div style="margin-top:10px;border-top:4px solid;border-style:double;width:70%;" ></div></div></a>
   
    
  </div>
</div>
</div>

<input type='number' id="border_weight_def" value="1" style="text-align:center;width:40px;"/><span style="padding:10px;color:black">px</span>
</div>

<div style="color:black;font-weight:600;font-size:20px;padding:10px">
outline setting
</div>
<div class="row" style="padding:25px;">
<div style="width:50%">
<div class="dropdown" style="width:100%;padding-left:10px;padding-right:10px;">

<button class="borer-type" style="height:40px;background:#f2f2f2;width:100%;background:none;" data-toggle="dropdown">outline type <span><i class="fas fa-chevron-down"></i></span></button>
  
  <div class="dropdown-menu" style="border-radius:0px;box-shadow:none;border:1px solid #f2f2f2;width:100%">
    <a class="dropdown-item outline-dec" id="none"   href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">none</div><div style="margin-top:10px;width:70%;" ></div></div></a>
    <a class="dropdown-item outline-dec" id="dotted"   href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">dotted</div><div style="margin-top:10px;border-top:4px solid;border-style:dotted;width:70%;" ></div></div></a>
    <a class="dropdown-item outline-dec" id="dashed"   href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">dashed</div><div style="margin-top:10px;border:none;border-top:4px;border-style:dashed;width:70%;" ></div></div></a>
    <a class="dropdown-item outline-dec" id="solid"    href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">solid</div><div style="margin-top:10px;border-top:4px solid;border-style:solid;width:70%;" ></div></div></a>
    <a class="dropdown-item outline-dec" id="double"   href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">double</div><div style="margin-top:10px;border-top:4px solid;border-style:double;width:70%;" ></div></div></a>
    <a class="dropdown-item outline-dec" id="groove"    href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">groove</div><div style="margin-top:10px;border-top:4px solid;border-style:groove;width:70%;" ></div></div></a>
    <a class="dropdown-item outline-dec" id="ridge"   href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">ridge</div><div style="margin-top:10px;border-top:4px solid;border-style:ridge;width:70%;" ></div></div></a>
    <a class="dropdown-item outline-dec" id="outset"    href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">outset</div><div style="margin-top:10px;border-top:4px solid;border-style:outset;width:70%;" ></div></div></a>
    <a class="dropdown-item outline-dec" id="inset"   href="#"><div class="row" style="margin:0 auto;"><div style="width:30%">inset</div><div style="margin-top:10px;border-top:4px solid;border-style:inset;width:70%;" ></div></div></a>

    
  </div>
</div>
</div>

<input type='number' id="outline_weight_def" value="1" style="text-align:center;width:40px;"/><span style="padding:10px;color:black">px</span>
</div>

<div style="color:black;font-weight:600;font-size:20px;padding:10px;">
Border corner setting
</div>
<div style="padding:20px;">
<input type="range" min="1" max="100" value="" class="slider" id="myRange">
</div>